<!DOCTYPE html>
<html>
<head>
<title>Smart Parking System</title>

<style>

/* Reset */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Segoe UI', sans-serif;
}

/* Background */
body{
    height:100vh;
    background: linear-gradient(135deg, #1d3557, #457b9d);
    display:flex;
    align-items:center;
    justify-content:center;
}

/* Main Card */
.container{
    width:900px;
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(15px);
    border-radius:15px;
    padding:40px;
    color:white;
    box-shadow:0 0 30px rgba(0,0,0,0.3);
}

/* Title */
h1{
    text-align:center;
    margin-bottom:10px;
}

p{
    text-align:center;
    margin-bottom:30px;
    color:#ddd;
}

/* Buttons */
.buttons{
    display:flex;
    justify-content:center;
    gap:40px;
    margin-bottom:40px;
}

.btn{
    padding:20px 40px;
    font-size:18px;
    border:none;
    border-radius:10px;
    cursor:pointer;
    transition:0.3s;
    text-decoration:none;
    color:white;
}

/* Admin Button */
.admin{
    background:#e63946;
}

.admin:hover{
    background:#ff4d5a;
    transform:scale(1.05);
}

/* Security Button */
.security{
    background:#2a9d8f;
}

.security:hover{
    background:#38b6a4;
    transform:scale(1.05);
}

/* About Section */
.about{
    background: rgba(255,255,255,0.15);
    padding:20px;
    border-radius:10px;
    line-height:1.6;
}

/* Footer */
.footer{
    text-align:center;
    margin-top:20px;
    font-size:14px;
    color:#ccc;
}

</style>

</head>
<body>

<div class="container">

<h1>🚗 Smart Parking System</h1>
<p>Manage Society Parking Efficiently & Smartly</p>

<div class="buttons">

<a href="admin/admin-login.php" class="btn admin">
🔐 Admin Panel
</a>

<a href="security/security-login.php" class="btn security">
🚓 Security Panel
</a>

</div>

<div class="about">

<h3>About This System</h3>

<p>
This Smart Parking System is designed to manage parking inside a society.
It helps administrators and security staff to track vehicle entries,
manage resident and guest parking, and monitor parking slot availability in real-time.
</p>

<p>
✔ Manage Wings, Units & Residents<br>
✔ Track Resident & Guest Parking<br>
✔ Auto Slot Assignment<br>
✔ Entry & Exit Monitoring<br>
✔ Reports & Search System
</p>

</div>

<div class="footer">
© 2026 Smart Parking System | Developed by Siddharth & Devvrat🚀
</div>

</div>

</body>
</html>