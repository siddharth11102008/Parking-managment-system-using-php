<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$result = mysqli_query($conn,"SELECT * FROM users WHERE role='security'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Security Staff List</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

/* ===== MAIN CONTAINER ===== */
.container{
    width:92%;
    margin:30px auto;
    position:relative;
    z-index:1;
}

/* ===== PAGE HEADER ===== */
.page-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
    padding:18px 22px;
    background:linear-gradient(135deg,#2c3e50,#34495e);
    border-radius:10px;
    color:white;
    box-shadow:0 4px 15px rgba(0,0,0,0.2);
}

.page-header h2{
    font-size:20px;
    font-weight:600;
}

/* ADD BUTTON */
.add{
    background:linear-gradient(45deg,#27ae60,#2ecc71);
    color:white;
    padding:10px 16px;
    text-decoration:none;
    border-radius:25px;
    font-size:13px;
    font-weight:bold;
    transition:0.3s;
}

.add:hover{
    transform:scale(1.05);
    background:linear-gradient(45deg,#1e8449,#27ae60);
}

/* ===== TABLE CARD ===== */
.table-box{
    background:white;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    overflow:visible;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background:linear-gradient(45deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:14px;
}

/* CELLS */
td{
    padding:13px;
    text-align:center;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* ZEBRA */
tr:nth-child(even){
    background:#f9fbfc;
}

/* HOVER */
tr:hover{
    background:#eef5ff;
    transition:0.2s;
}

/* STATUS BADGE */
.status{
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:bold;
    color:white;
}

.active{
    background:#27ae60;
}

.inactive{
    background:#e74c3c;
}

/* BUTTONS */
.btn{
    padding:6px 14px;
    color:white;
    text-decoration:none;
    border-radius:20px;
    font-size:12px;
    margin:2px;
    display:inline-block;
    transition:0.3s;
}

.view{
    background:#3498db;
}
.view:hover{
    background:#2c80b4;
}

.edit{
    background:#f39c12;
}
.edit:hover{
    background:#d68910;
}

.delete{
    background:#e74c3c;
}
.delete:hover{
    background:#c0392b;
}

/* EMPTY DATA */
.empty{
    padding:20px;
    text-align:center;
    color:#888;
}

/* RESPONSIVE */
@media(max-width:768px){
    table,thead,tbody,th,td,tr{
        display:block;
    }

    th{
        display:none;
    }

    tr{
        margin-bottom:15px;
        background:white;
        border-radius:10px;
        padding:10px;
        box-shadow:0 5px 10px rgba(0,0,0,0.05);
    }

    td{
        text-align:left;
        padding:8px;
        border:none;
    }

    td:before{
        content:attr(data-label);
        font-weight:bold;
        display:block;
        color:#555;
    }
}

/* PREVENT CUT */
body, html{
    overflow-x:hidden;
}
</style>

</head>
<body>

<div class="container">

    <div class="page-header">
        <h2>👮 Security Staff List</h2>
        <a href="security-add.php" class="add">+ Add Security</a>
    </div>

    <div class="table-box">

        <table>

            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php if(mysqli_num_rows($result) > 0){ ?>
                <?php while($row=mysqli_fetch_assoc($result)){ ?>
                <tr>

                    <td data-label="Name"><?php echo $row['name']; ?></td>

                    <td data-label="Email"><?php echo $row['email']; ?></td>

                    <td data-label="Mobile"><?php echo $row['mobile']; ?></td>

                    <td data-label="Status">
                        <span class="status <?php echo $row['status']=='active' ? 'active' : 'inactive'; ?>">
                            <?php echo ucfirst($row['status']); ?>
                        </span>
                    </td>

                    <td data-label="Action">
                        <a href="security-view.php?id=<?php echo $row['user_id']; ?>" class="btn view">View</a>
                        <a href="security-edit.php?id=<?php echo $row['user_id']; ?>" class="btn edit">Edit</a>
                        <a href="security-delete.php?id=<?php echo $row['user_id']; ?>" 
                           class="btn delete"
                           onclick="return confirm('Are you sure?')">Delete</a>
                    </td>

                </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="5" class="empty">No Security Staff Found</td>
                </tr>
            <?php } ?>

        </table>

    </div>

</div>

</body>
</html>