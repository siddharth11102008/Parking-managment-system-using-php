<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$result = mysqli_query($conn,"
SELECT r.*, u.unit_number, w.wing_name 
FROM residents r
JOIN units u ON r.unit_id = u.unit_id
JOIN wings w ON u.wing_id = w.wing_id
ORDER BY r.resident_id ASC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Resident List</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* PAGE WRAPPER */
.container{
    width:92%;
    margin:40px auto;
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#2c3e50;
    font-size:22px;
}

/* TOP BAR */
.top{
    display:flex;
    justify-content:flex-end;
    margin-bottom:15px;
}

/* ADD BUTTON */
.add{
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    padding:10px 16px;
    text-decoration:none;
    border-radius:10px;
    font-size:14px;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
    transition:0.3s;
}

.add:hover{
    transform:translateY(-2px);
}

/* TABLE WRAPPER */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
    letter-spacing:0.5px;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
    color:#2c3e50;
}

/* HOVER EFFECT */
tr:hover{
    background:#f9fbff;
}

/* ACTION BUTTONS */
a{
    text-decoration:none;
    padding:7px 10px;
    border-radius:8px;
    font-size:12px;
    margin:0 3px;
    transition:0.3s;
    display:inline-block;
}

/* VIEW */
.view{
    background: linear-gradient(90deg,#3498db,#5dade2);
    color:white;
    box-shadow:0 4px 10px rgba(52,152,219,0.3);
}

/* EDIT */
.edit{
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
}

/* DELETE */
.delete{
    background: linear-gradient(90deg,#e74c3c,#ff6b6b);
    color:white;
}

/* STATUS BADGES */
.badge{
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.active{
    background:#e8f8f0;
    color:#27ae60;
}

.inactive{
    background:#fdecea;
    color:#e74c3c;
}

/* EMPTY STATE */
.empty{
    text-align:center;
    padding:20px;
    color:#7f8c8d;
}
</style>

</head>

<body>

<div class="container">

<h2>👥 Resident List</h2>

<div class="top">
    <a href="resident-add.php" class="add">+ Add Resident</a>
</div>

<div class="table-box">

<table>

<tr>
<th>Name</th>
<th>Wing</th>
<th>Unit</th>
<th>Mobile</th>
<th>Type</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php if(mysqli_num_rows($result) > 0){ ?>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['wing_name']; ?></td>
<td><?php echo $row['unit_number']; ?></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo ucfirst($row['resident_type']); ?></td>

<td>
<span class="badge <?php echo $row['status']; ?>">
<?php echo ucfirst($row['status']); ?>
</span>
</td>

<td>
<a href="resident-view.php?id=<?php echo $row['resident_id']; ?>" class="view">View</a>
<a href="resident-edit.php?id=<?php echo $row['resident_id']; ?>" class="edit">Edit</a>
<a href="resident-delete.php?id=<?php echo $row['resident_id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
</td>

</tr>
<?php } ?>

<?php } else { ?>
<tr>
<td colspan="7" class="empty">No residents found</td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>