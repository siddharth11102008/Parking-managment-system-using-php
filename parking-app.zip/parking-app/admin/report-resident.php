<?php
include("admin-header.php");
$conn = mysqli_connect("localhost","root","","parking_db");

$result = mysqli_query($conn,"
    SELECT r.*, u.unit_number
    FROM residents r
    JOIN units u ON r.unit_id = u.unit_id
    ORDER BY r.resident_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Resident Report</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background:linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* MAIN CONTAINER */
.container{
    width:92%;
    margin:35px auto;
    background:white;
    padding:25px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
h2{
    margin:0 0 20px;
    color:#2c3e50;
    font-size:22px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    border-radius:12px;
    overflow:hidden;
}

/* HEADER */
th{
    background:linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
}

/* CELLS */
td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* ROW EFFECT */
tr:hover{
    background:#f1f7ff;
    transition:0.2s;
}

/* STRIPED ROW */
tr:nth-child(even){
    background:#fafafa;
}

/* STATUS BADGES */
.status-active{
    color:#fff;
    background:#2ecc71;
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}

.status-inactive{
    color:#fff;
    background:#e74c3c;
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}

/* TYPE BADGE */
.type{
    background:#3498db;
    color:white;
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}
</style>

</head>

<body>

<div class="container">

<h2>🏠 Resident Report</h2>

<table>
<tr>
<th>Name</th>
<th>Unit</th>
<th>Mobile</th>
<th>Email</th>
<th>Type</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>
<td><b><?php echo $row['name']; ?></b></td>
<td><?php echo $row['unit_number']; ?></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo $row['email']; ?></td>

<td>
<span class="type">
<?php echo ucfirst($row['resident_type']); ?>
</span>
</td>

<td>
<span class="status-<?php echo $row['status']; ?>">
<?php echo ucfirst($row['status']); ?>
</span>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>