<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$id = (int)$_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT * FROM users 
    WHERE user_id=$id AND role='security'
"));

if(!$data){
    die("Security Not Found");
}

if(isset($_POST['update'])){
    $name   = $_POST['name'];
    $email  = $_POST['email'];
    $mobile = $_POST['mobile'];
    $status = $_POST['status'];

    mysqli_query($conn,"UPDATE users SET
        name='$name',
        email='$email',
        mobile='$mobile',
        status='$status'
        WHERE user_id=$id
    ");

    header("Location: security-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Security</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

/* Container */
.container{
    width:420px;
    margin:60px auto;
}

/* Card */
.box{
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    animation:fadeIn 0.4s ease;
}

/* Heading */
h2{
    text-align:center;
    margin-bottom:20px;
    color:#2c3e50;
}

/* Inputs */
input, select{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:14px;
    transition:0.3s;
}

input:focus, select:focus{
    border-color:#3498db;
    box-shadow:0 0 5px rgba(52,152,219,0.3);
    outline:none;
}

/* Button */
button{
    width:100%;
    padding:12px;
    background:linear-gradient(45deg,#f39c12,#f1c40f);
    color:white;
    border:none;
    border-radius:25px;
    cursor:pointer;
    font-size:15px;
    font-weight:bold;
    transition:0.3s;
}

button:hover{
    background:linear-gradient(45deg,#d68910,#f39c12);
}

/* Back Button */
.back{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#2c3e50;
    font-weight:bold;
    transition:0.3s;
}

.back:hover{
    color:#3498db;
}

/* Label */
label{
    font-size:13px;
    color:#555;
}

/* Animation */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(15px);}
    to{opacity:1; transform:translateY(0);}
}

/* Mobile */
@media(max-width:480px){
    .container{
        width:90%;
        margin:30px auto;
    }
}
</style>

</head>
<body>

<div class="container">

<div class="box">

<h2>✏️ Edit Security Staff</h2>

<form method="POST">

<label>Name</label>
<input type="text" name="name" value="<?php echo $data['name']; ?>" required>

<label>Email</label>
<input type="email" name="email" value="<?php echo $data['email']; ?>" required>

<label>Mobile</label>
<input type="text" name="mobile" value="<?php echo $data['mobile']; ?>" required>

<label>Status</label>
<select name="status">
    <option value="active" <?php if($data['status']=='active') echo 'selected'; ?>>Active</option>
    <option value="inactive" <?php if($data['status']=='inactive') echo 'selected'; ?>>Inactive</option>
</select>

<button type="submit" name="update">Update Security</button>

</form>

<a href="security-list.php" class="back">← Back to List</a>

</div>

</div>

</body>
</html>