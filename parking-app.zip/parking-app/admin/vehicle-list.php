<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$result = mysqli_query($conn,"
SELECT v.*, r.name, u.unit_number, w.wing_name
FROM vehicles v
JOIN residents r ON v.resident_id = r.resident_id
JOIN units u ON r.unit_id = u.unit_id
JOIN wings w ON u.wing_id = w.wing_id
ORDER BY v.vehicle_id ASC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Vehicle List</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* PAGE WRAPPER */
.container{
    width:92%;
    margin:40px auto;
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#2c3e50;
}

/* TOP BAR */
.top{
    display:flex;
    justify-content:flex-end;
    margin-bottom:15px;
}

/* ADD BUTTON */
.add{
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    padding:10px 16px;
    text-decoration:none;
    border-radius:10px;
    font-size:14px;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
    transition:0.3s;
}

.add:hover{
    transform:translateY(-2px);
}

/* TABLE CARD */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
    color:#2c3e50;
}

/* HOVER */
tr:hover{
    background:#f9fbff;
}

/* ACTION BUTTONS */
a{
    text-decoration:none;
    padding:7px 10px;
    border-radius:8px;
    font-size:12px;
    margin:0 3px;
    display:inline-block;
    transition:0.3s;
}

/* EDIT */
.edit{
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
}

/* DELETE */
.delete{
    background: linear-gradient(90deg,#e74c3c,#ff6b6b);
    color:white;
}

/* BADGE STYLE */
.badge{
    display:inline-block;
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    background:#e8f0fe;
    color:#3498db;
}

/* EMPTY */
.empty{
    text-align:center;
    padding:20px;
    color:#7f8c8d;
}
</style>

</head>

<body>

<div class="container">

<h2>🚗 Vehicle List</h2>

<div class="top">
    <a href="vehicle-add.php" class="add">+ Add Vehicle</a>
</div>

<div class="table-box">

<table>

<tr>
<th>Vehicle Number</th>
<th>Type</th>
<th>Owner</th>
<th>Wing</th>
<th>Unit</th>
<th>Action</th>
</tr>

<?php if(mysqli_num_rows($result) > 0){ ?>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>

<td><span class="badge"><?php echo $row['vehicle_number']; ?></span></td>
<td><?php echo ucfirst($row['vehicle_type']); ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['wing_name']; ?></td>
<td><?php echo $row['unit_number']; ?></td>

<td>
<a href="vehicle-edit.php?id=<?php echo $row['vehicle_id']; ?>" class="edit">Edit</a>
<a href="vehicle-delete.php?id=<?php echo $row['vehicle_id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
</td>

</tr>
<?php } ?>

<?php } else { ?>
<tr>
<td colspan="6" class="empty">No vehicles found</td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>