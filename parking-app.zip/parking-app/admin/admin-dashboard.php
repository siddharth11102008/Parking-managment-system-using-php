<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$totalUsers = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM users"));
$totalSlots = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM parking_slots"));
$totalResidents = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM residents"));
$totalVehicles = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM vehicles"));

$todayVisitors = mysqli_num_rows(mysqli_query($conn,"
    SELECT * FROM guest_parking_logs 
    WHERE DATE(entry_time) = CURDATE()
"));
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>

<style>
body{
    margin:0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(180deg, #f7f9fc 0%, #eef2f7 100%);
}

/* PAGE WRAPPER */
.container{
    width:92%;
    margin:40px auto;
}

/* WELCOME SECTION */
.welcome{
    background: #ffffff;
    padding:25px;
    border-radius:16px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    margin-bottom:30px;
    border-left:6px solid #4a90e2;
}

.welcome h2{
    margin:0;
    font-size:22px;
    color:#2c3e50;
    font-weight:600;
}

.welcome p{
    margin-top:6px;
    color:#7f8c8d;
}

/* GRID */
.cards{
    display:grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap:22px;
}

/* CARD */
.card{
    background:#fff;
    padding:22px;
    border-radius:18px;
    position:relative;
    box-shadow: 0 8px 25px rgba(0,0,0,0.06);
    transition: all 0.3s ease;
    overflow:hidden;
}

.card:hover{
    transform: translateY(-6px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.12);
}

/* TOP COLOR BAR */
.card::before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    width:100%;
    height:4px;
}

/* COLORS */
.blue::before{background:linear-gradient(90deg,#4facfe,#00f2fe);}
.green::before{background:linear-gradient(90deg,#43e97b,#38f9d7);}
.orange::before{background:linear-gradient(90deg,#fa709a,#fee140);}
.purple::before{background:linear-gradient(90deg,#a18cd1,#fbc2eb);}
.red::before{background:linear-gradient(90deg,#ff758c,#ff7eb3);}

/* TEXT */
.card h3{
    margin:0;
    font-size:13px;
    color:#95a5a6;
    font-weight:600;
    letter-spacing:0.5px;
    text-transform:uppercase;
}

.card p{
    margin-top:12px;
    font-size:30px;
    font-weight:700;
    color:#2c3e50;
}

/* ICON STYLE */
.icon{
    position:absolute;
    right:18px;
    top:18px;
    font-size:26px;
    opacity:0.15;
}
</style>

</head>
<body>

<?php include 'admin-header.php'; ?>

<div class="container">

    <div class="welcome">
        <h2>Welcome back, <?php echo $_SESSION['admin']; ?> 👋</h2>
        <p>Here’s your parking system overview today</p>
    </div>

    <div class="cards">

        <div class="card blue">
            <h3>Total Users</h3>
            <p><?php echo $totalUsers; ?></p>
        </div>

        <div class="card green">
            <h3>Parking Slots</h3>
            <p><?php echo $totalSlots; ?></p>
        </div>

        <div class="card orange">
            <h3>Residents</h3>
            <p><?php echo $totalResidents; ?></p>
        </div>

        <div class="card purple">
            <h3>Vehicles</h3>
            <p><?php echo $totalVehicles; ?></p>
        </div>

        <div class="card red">
            <h3>Today's Visitors</h3>
            <p><?php echo $todayVisitors; ?></p>
        </div>

    </div>

</div>

</body>
</html>