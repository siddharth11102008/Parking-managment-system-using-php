<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM parking_slots WHERE slot_id=$id");

header("Location: slot-list.php");
exit();
?>
