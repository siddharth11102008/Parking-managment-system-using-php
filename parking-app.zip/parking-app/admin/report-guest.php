<?php
include("admin-header.php");
$conn = mysqli_connect("localhost","root","","parking_db");

$result = mysqli_query($conn,"SELECT * FROM guest_parking_logs");
?>

<!DOCTYPE html>
<html>
<head>
<title>Guest Report</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background:linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* MAIN CONTAINER */
.container{
    width:92%;
    margin:35px auto;
    background:white;
    padding:25px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
h2{
    margin:0 0 20px;
    color:#2c3e50;
    font-size:22px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    border-radius:12px;
    overflow:hidden;
}

/* HEADER */
th{
    background:linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
}

/* CELLS */
td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* ROW HOVER */
tr:hover{
    background:#f1f7ff;
    transition:0.2s;
}

/* STRIPED */
tr:nth-child(even){
    background:#fafafa;
}

/* BADGE BASE */
.badge{
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}

/* INSIDE */
.inside{
    background:#f39c12;
    color:white;
}

/* EXITED */
.exited{
    background:#2ecc71;
    color:white;
}

/* ENTRY / EXIT TIME STYLE */
td:nth-child(3),
td:nth-child(4){
    font-weight:500;
    color:#2c3e50;
}
</style>

</head>

<body>

<div class="container">

<h2>🚗 Guest Parking Report</h2>

<table>
<tr>
<th>Visitor</th>
<th>Vehicle</th>
<th>Entry Time</th>
<th>Exit Time</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>

<td><b><?php echo $row['visitor_name']; ?></b></td>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['entry_time']; ?></td>
<td><?php echo $row['exit_time'] ?: '—'; ?></td>

<td>
<span class="badge <?php echo $row['exit_time'] ? 'exited' : 'inside'; ?>">
<?php echo $row['exit_time'] ? 'Exited' : 'Inside'; ?>
</span>
</td>

</tr>
<?php } ?>

</table>

</div>

</body>
</html>