<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM residents WHERE resident_id=$id");

header("Location: resident-list.php");
exit();
?>
