<?php
include 'admin-header.php';

$conn = mysqli_connect("localhost","root","","parking_db");

// CHECK LOGIN
if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit();
}

// CHANGE PASSWORD LOGIC
if(isset($_POST['change'])){
    $newpass = $_POST['newpass'];
    $admin_id = $_SESSION['admin_id'];

    if($newpass == ""){
        $msg = "Password cannot be empty!";
    } else {

        $update = mysqli_query($conn,"
            UPDATE users 
            SET password='$newpass' 
            WHERE user_id='$admin_id'
        ");

        if($update){
            $msg = "Password changed successfully!";
        } else {
            $msg = "Error updating password!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Change Password</title>

<style>

/* PAGE WRAPPER (SAFE FOR HEADER) */
.page{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg,#eef2f7,#f8fbff);
}

/* CARD */
.box{
    width:400px;
    padding:30px;
    border-radius:18px;
    background: rgba(255,255,255,0.9);
    backdrop-filter: blur(12px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.12);
    text-align:center;
    position:relative;
    transition:0.3s;
}

.box:hover{
    transform: translateY(-5px);
}

/* TAG */
.tag{
    position:absolute;
    top:-12px;
    left:20px;
    background:linear-gradient(90deg,#9b59b6,#8e44ad);
    color:white;
    padding:5px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

/* TITLE */
h2{
    margin-bottom:20px;
    color:#2c3e50;
}

/* INPUT */
input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:10px;
    border:1px solid #ddd;
    font-size:14px;
    transition:0.3s;
}

input:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    margin-top:10px;
    border:none;
    border-radius:10px;
    background:linear-gradient(90deg,#3498db,#2980b9);
    color:white;
    font-weight:600;
    font-size:15px;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 8px 20px rgba(52,152,219,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 12px 25px rgba(52,152,219,0.4);
}

/* MESSAGE */
.msg{
    margin-bottom:10px;
    padding:10px;
    border-radius:8px;
    font-size:13px;
    background:#ecf9f1;
    color:#27ae60;
    border-left:4px solid #2ecc71;
}

/* BACK LINK */
.back{
    display:inline-block;
    margin-top:15px;
    text-decoration:none;
    color:#3498db;
    font-size:13px;
    font-weight:500;
}

.back:hover{
    text-decoration:underline;
}

/* ICON */
.icon{
    width:60px;
    height:60px;
    margin:0 auto 10px;
    border-radius:50%;
    background:linear-gradient(135deg,#3498db,#2c3e50);
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-size:26px;
    box-shadow:0 8px 20px rgba(0,0,0,0.2);
}

</style>

</head>

<body>

<div class="page">

<div class="box">

<div class="tag">SECURITY</div>

<div class="icon">🔐</div>

<h2>Change Password</h2>

<?php if(isset($msg)) echo "<div class='msg'>$msg</div>"; ?>

<form method="POST">
<input type="password" name="newpass" placeholder="Enter New Password" required>
<button type="submit" name="change">Update Password</button>
</form>

<a href="admin-dashboard.php" class="back">← Back to Dashboard</a>

</div>

</div>

</body>
</html>