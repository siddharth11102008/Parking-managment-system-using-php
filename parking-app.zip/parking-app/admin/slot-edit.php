<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT * FROM parking_slots WHERE slot_id=$id
"));

if(isset($_POST['update'])){
    $slot_number = $_POST['slot_number'];
    $slot_type = $_POST['slot_type'];
    $status = $_POST['status'];

    mysqli_query($conn,"UPDATE parking_slots SET
        slot_number='$slot_number',
        slot_type='$slot_type',
        status='$status'
        WHERE slot_id=$id
    ");

    header("Location: slot-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Slot</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:420px;
    background:#fff;
    padding:30px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
}

/* LABEL */
label{
    font-size:13px;
    color:#7f8c8d;
    display:block;
    margin-top:10px;
}

/* INPUT + SELECT */
input,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    margin-bottom:12px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus,select:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(243,156,18,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(243,156,18,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#3498db;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#3498db;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}

/* STATUS PREVIEW BOX */
.preview{
    display:inline-block;
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
    margin-bottom:10px;
}

.available{background:#e8f8f0;color:#27ae60;}
.occupied{background:#fdecea;color:#e74c3c;}
.reserved{background:#fff4e5;color:#f39c12;}
.blocked{background:#ecf0f1;color:#2c3e50;}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">EDIT SLOT</div>

<h2>🅿️ Update Parking Slot</h2>

<!-- CURRENT STATUS PREVIEW -->
<p>
Current Status:
<span class="preview <?php echo $data['status']; ?>">
<?php echo ucfirst($data['status']); ?>
</span>
</p>

<form method="POST">

<label>Slot Number</label>
<input type="text" name="slot_number" value="<?php echo $data['slot_number']; ?>" required>

<label>Slot Type</label>
<select name="slot_type">
<option value="resident" <?php if($data['slot_type']=="resident") echo "selected"; ?>>Resident</option>
<option value="guest" <?php if($data['slot_type']=="guest") echo "selected"; ?>>Guest</option>
</select>

<label>Status</label>
<select name="status">
<option value="available" <?php if($data['status']=="available") echo "selected"; ?>>Available</option>
<option value="occupied" <?php if($data['status']=="occupied") echo "selected"; ?>>Occupied</option>
<option value="reserved" <?php if($data['status']=="reserved") echo "selected"; ?>>Reserved</option>
<option value="blocked" <?php if($data['status']=="blocked") echo "selected"; ?>>Blocked</option>
</select>

<button type="submit" name="update">Update Slot</button>

</form>

<a href="slot-list.php">← Back to Slot List</a>

</div>

</div>

</body>
</html>