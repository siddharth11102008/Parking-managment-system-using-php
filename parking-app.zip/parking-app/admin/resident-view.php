<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT r.*, u.unit_number, w.wing_name 
FROM residents r
JOIN units u ON r.unit_id=u.unit_id
JOIN wings w ON u.wing_id=w.wing_id
WHERE r.resident_id=$id
"));
?>

<!DOCTYPE html>
<html>
<head>
<title>View Resident</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER WRAPPER */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:480px;
    background:#fff;
    padding:30px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* HEADER */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
    font-size:22px;
}

/* DETAILS GRID */
.info{
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap:12px 20px;
}

/* LABEL */
label{
    font-size:12px;
    color:#95a5a6;
    display:block;
    margin-bottom:4px;
}

/* VALUE */
.value{
    font-size:14px;
    color:#2c3e50;
    font-weight:600;
}

/* ROW ITEM */
.item{
    background:#f9fbff;
    padding:10px;
    border-radius:10px;
    border:1px solid #eef2f7;
}

/* BADGES */
.badge{
    display:inline-block;
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.active{
    background:#e8f8f0;
    color:#27ae60;
}

.inactive{
    background:#fdecea;
    color:#e74c3c;
}

/* BACK BUTTON */
a{
    display:block;
    text-align:center;
    margin-top:20px;
    text-decoration:none;
    color:white;
    background: linear-gradient(90deg,#3498db,#5dade2);
    padding:10px;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

a:hover{
    transform:translateY(-2px);
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#3498db;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">RESIDENT PROFILE</div>

<h2>👤 Resident Details</h2>

<div class="info">

<div class="item">
<label>Name</label>
<div class="value"><?php echo $data['name']; ?></div>
</div>

<div class="item">
<label>Wing</label>
<div class="value"><?php echo $data['wing_name']; ?></div>
</div>

<div class="item">
<label>Unit</label>
<div class="value"><?php echo $data['unit_number']; ?></div>
</div>

<div class="item">
<label>Mobile</label>
<div class="value"><?php echo $data['mobile']; ?></div>
</div>

<div class="item">
<label>Email</label>
<div class="value"><?php echo $data['email']; ?></div>
</div>

<div class="item">
<label>Type</label>
<div class="value"><?php echo ucfirst($data['resident_type']); ?></div>
</div>

<div class="item">
<label>Status</label>
<div class="value">
<span class="badge <?php echo $data['status']; ?>">
<?php echo ucfirst($data['status']); ?>
</span>
</div>
</div>


</div>

<a href="resident-list.php">← Back to List</a>

</div>

</div>

</body>
</html>