<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT * FROM vehicles WHERE vehicle_id=$id
"));

$residents = mysqli_query($conn,"
SELECT r.resident_id, r.name, u.unit_number, w.wing_name
FROM residents r
JOIN units u ON r.unit_id=u.unit_id
JOIN wings w ON u.wing_id=w.wing_id
WHERE r.status='active'
ORDER BY r.name ASC
");

if(isset($_POST['update'])){
    $resident_id = $_POST['resident_id'];
    $vehicle_number = $_POST['vehicle_number'];
    $vehicle_type = $_POST['vehicle_type'];

    mysqli_query($conn,"UPDATE vehicles SET
        resident_id='$resident_id',
        vehicle_number='$vehicle_number',
        vehicle_type='$vehicle_type'
        WHERE vehicle_id=$id
    ");

    header("Location: vehicle-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Vehicle</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:480px;
    background:#fff;
    padding:30px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
}

/* LABEL */
label{
    font-size:13px;
    color:#7f8c8d;
    display:block;
    margin-top:10px;
}

/* INPUT + SELECT */
input,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    margin-bottom:12px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus,select:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(243,156,18,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(243,156,18,0.4);
}

/* BACK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#3498db;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#3498db;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">EDIT VEHICLE</div>

<h2>🚗 Update Vehicle</h2>

<form method="POST">

<label>Select Owner</label>
<select name="resident_id" required>
<?php while($r=mysqli_fetch_assoc($residents)){ ?>
<option value="<?php echo $r['resident_id']; ?>"
<?php if($data['resident_id']==$r['resident_id']) echo "selected"; ?>>
<?php echo $r['name']." (".$r['wing_name']." - ".$r['unit_number'].")"; ?>
</option>
<?php } ?>
</select>

<label>Vehicle Number</label>
<input type="text" name="vehicle_number" value="<?php echo $data['vehicle_number']; ?>" required>

<label>Vehicle Type</label>
<select name="vehicle_type">
<option value="2W" <?php if($data['vehicle_type']=="2W") echo "selected"; ?>>2 Wheeler</option>
<option value="4W" <?php if($data['vehicle_type']=="4W") echo "selected"; ?>>4 Wheeler</option>
</select>

<button type="submit" name="update">Update Vehicle</button>

</form>

<a href="vehicle-list.php">← Back to List</a>

</div>

</div>

</body>
</html>