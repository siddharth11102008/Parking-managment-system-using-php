<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$result = mysqli_query($conn,"
SELECT s.*, r.name 
FROM parking_slots s
LEFT JOIN residents r ON s.assigned_resident_id = r.resident_id
ORDER BY s.slot_id ASC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Parking Slot List</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* PAGE WRAPPER */
.container{
    width:92%;
    margin:40px auto;
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#2c3e50;
}

/* TOP BAR */
.top{
    display:flex;
    justify-content:flex-end;
    margin-bottom:15px;
}

/* ADD BUTTON */
.add{
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    padding:10px 16px;
    text-decoration:none;
    border-radius:10px;
    font-size:14px;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
    transition:0.3s;
}

.add:hover{
    transform:translateY(-2px);
}

/* TABLE CARD */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
    color:#2c3e50;
}

/* HOVER */
tr:hover{
    background:#f9fbff;
}

/* STATUS BADGES */
.status{
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}

/* AVAILABLE */
.available{
    background:#e8f8f0;
    color:#27ae60;
}

/* OCCUPIED */
.occupied{
    background:#fdecea;
    color:#e74c3c;
}

/* RESERVED */
.reserved{
    background:#fff4e5;
    color:#f39c12;
}

/* BLOCKED */
.blocked{
    background:#ecf0f1;
    color:#2c3e50;
}

/* ACTION BUTTONS */
a{
    text-decoration:none;
    padding:7px 10px;
    border-radius:8px;
    font-size:12px;
    margin:0 3px;
    display:inline-block;
    transition:0.3s;
}

/* EDIT */
.edit{
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
}

/* DELETE */
.delete{
    background: linear-gradient(90deg,#e74c3c,#ff6b6b);
    color:white;
}

/* ASSIGN */
.assign{
    background: linear-gradient(90deg,#3498db,#5dade2);
    color:white;
}

/* EMPTY */
.empty{
    text-align:center;
    padding:20px;
    color:#7f8c8d;
}
</style>

</head>

<body>

<div class="container">

<h2>🅿️ Parking Slot Management</h2>

<div class="top">
    <a href="slot-add.php" class="add">+ Add Slot</a>
</div>

<div class="table-box">

<table>

<tr>
<th>Slot Number</th>
<th>Type</th>
<th>Status</th>
<th>Assigned To</th>
<th>Action</th>
</tr>

<?php if(mysqli_num_rows($result) > 0){ ?>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>

<td><strong><?php echo $row['slot_number']; ?></strong></td>
<td><?php echo ucfirst($row['slot_type']); ?></td>

<td>
<span class="status <?php echo $row['status']; ?>">
<?php echo ucfirst($row['status']); ?>
</span>
</td>

<td>
<?php echo $row['name'] ? $row['name'] : "—"; ?>
</td>

<td>
<a href="slot-edit.php?id=<?php echo $row['slot_id']; ?>" class="edit">Edit</a>
<a href="slot-delete.php?id=<?php echo $row['slot_id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>

<?php if($row['slot_type']=="resident"){ ?>
<a href="assign-slot.php?id=<?php echo $row['slot_id']; ?>" class="assign">Assign</a>
<?php } ?>
</td>

</tr>
<?php } ?>

<?php } else { ?>
<tr>
<td colspan="5" class="empty">No parking slots found</td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>