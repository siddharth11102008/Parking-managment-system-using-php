<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$wings = mysqli_query($conn,"SELECT * FROM wings ORDER BY wing_name ASC");

if(isset($_POST['save'])){
    $wing_id = $_POST['wing_id'];
    $unit_number = $_POST['unit_number'];
    $floor_number = $_POST['floor_number'];

    mysqli_query($conn,"INSERT INTO units(wing_id, unit_number, floor_number) 
                        VALUES('$wing_id','$unit_number','$floor_number')");

    header("Location: unit-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Unit</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER WRAPPER */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:450px;
    background:#fff;
    padding:30px;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
    font-size:22px;
}

/* LABEL */
label{
    font-size:13px;
    color:#7f8c8d;
    display:block;
    margin-top:10px;
}

/* INPUT + SELECT */
input,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
    background:white;
}

input:focus,select:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(46,204,113,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    color:#3498db;
    text-decoration:none;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#2ecc71;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">ADD UNIT</div>

<h2>🏢 Create New Unit</h2>

<form method="POST">

<label>Select Wing</label>
<select name="wing_id" required>
<option value="">-- Select Wing --</option>
<?php while($w=mysqli_fetch_assoc($wings)){ ?>
<option value="<?php echo $w['wing_id']; ?>">
<?php echo $w['wing_name']; ?>
</option>
<?php } ?>
</select>

<label>Unit Number</label>
<input type="text" name="unit_number" placeholder="Enter Unit Number" required>

<label>Floor Number</label>
<input type="number" name="floor_number" placeholder="Enter Floor Number" required>

<button type="submit" name="save">Save Unit</button>

</form>

<a href="unit-list.php">← Back to Unit List</a>

</div>

</div>

</body>
</html>