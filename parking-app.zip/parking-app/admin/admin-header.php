<?php
session_start();

if(!isset($_SESSION['admin_id'])){
    header("Location: admin-login.php");
    exit();
}
?>

<style>
body{
    margin:0;
    font-family:Arial;
    background:#f4f6f9;
}

/* ===== HEADER ===== */
.header{
    background:#1f2a36;
    color:white;
    padding:0 20px;
    height:60px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    box-shadow:0 2px 8px rgba(0,0,0,0.2);
    position:sticky;
    top:0;
    z-index:9999; /* 🔥 FIX */
}

/* LOGO */
.logo{
    font-size:18px;
    font-weight:bold;
}

/* NAV */
.nav{
    display:flex;
    align-items:center;
    gap:6px;
}

/* LINKS */
.nav a{
    color:white;
    text-decoration:none;
    font-size:13px;
    padding:8px 10px;
    border-radius:5px;
}

.nav a:hover{
    background:#34495e;
}

/* ===== DROPDOWN ===== */
.dropdown{
    position:relative;
    display:flex;
    align-items:center;
}

/* BUTTON */
.dropbtn{
    color:white;
    font-size:13px;
    padding:8px 10px;
    border-radius:5px;
    cursor:pointer;
    user-select:none;
}

.dropbtn:hover{
    background:#34495e;
}

/* DROPDOWN MENU */
.dropdown-content{
    display:none;
    position:absolute;
    top:100%;
    right:0;

    background:white;
    min-width:190px;
    border-radius:8px;
    box-shadow:0 8px 20px rgba(0,0,0,0.3);
    padding:5px 0;

    z-index:99999; /* 🔥 MAIN FIX */
}

/* LINKS INSIDE DROPDOWN */
.dropdown-content a{
    color:#333;
    padding:10px 12px;
    display:block;
    font-size:13px;
    text-decoration:none;
}

.dropdown-content a:hover{
    background:#f1f1f1;
}

/* SHOW DROPDOWN */
.dropdown:hover .dropdown-content{
    display:block;
}

/* PROFILE */
.profile{
    margin-left:5px;
}

/* 🔥 IMPORTANT GLOBAL FIX */
.container, .table-box, .box{
    overflow:visible !important;
}
</style>

<div class="header">

    <div class="logo">🚗 Parking Admin Panel</div>

    <div class="nav">

        <a href="admin-dashboard.php">Dashboard</a>

        <a href="wing-list.php">Wings</a>
        <a href="unit-list.php">Units</a>
        <a href="resident-list.php">Residents</a>
        <a href="vehicle-list.php">Vehicles</a>
        <a href="slot-list.php">Slots</a>

        <!-- SECURITY DROPDOWN -->
        
        <a href="resident-log-list.php">Resident Logs</a>
        <a href="guest-log-list.php">Guest Logs</a>
        
        <a href="search.php">🔍 Search</a>
        <!-- REPORTS -->
        <div class="dropdown">
            <div class="dropbtn">📊 Reports ▾</div>
            <div class="dropdown-content">
                <a href="report-daily.php">Daily Report</a>
                <a href="report-resident.php">Resident Report</a>
                <a href="report-guest.php">Guest Report</a>
                <a href="report-fine.php">Fine Report</a>
            </div>
        </div>
        <div class="dropdown">
            <div class="dropbtn">👮 Security ▾</div>
            <div class="dropdown-content">
                <a href="security-add.php">Add Security</a>
                <a href="security-list.php">Security List</a>
            </div>
        </div>


        <!-- PROFILE -->
        <div class="dropdown profile">
            <div class="dropbtn">👤 <?php echo $_SESSION['admin']; ?> ▾</div>
            <div class="dropdown-content">
                <a href="profile.php">Profile</a>
                <a href="change-password.php">Change Password</a>
                <a href="admin-logout.php">Logout</a>
            </div>
        </div>

    </div>

</div>