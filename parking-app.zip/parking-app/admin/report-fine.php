<?php
include("admin-header.php");
$conn = mysqli_connect("localhost","root","","parking_db");

$result = mysqli_query($conn,"
    SELECT 
        g.visitor_name,
        g.vehicle_number,
        g.fine_amount,
        g.entry_time,
        g.exit_time,
        u.unit_number
    FROM guest_parking_logs g
    JOIN units u ON g.visiting_unit_id = u.unit_id
    WHERE g.fine_amount > 0
    ORDER BY g.guest_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Fine Report</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background:linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* CONTAINER */
.container{
    width:92%;
    margin:35px auto;
    background:white;
    padding:25px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TITLE */
h2{
    margin:0 0 20px;
    color:#c0392b;
    font-size:22px;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    border-radius:12px;
    overflow:hidden;
}

/* HEADER */
th{
    background:linear-gradient(90deg,#c0392b,#e74c3c);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
}

/* CELLS */
td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* ROW HOVER */
tr:hover{
    background:#fff3f3;
    transition:0.2s;
}

/* STRIPED */
tr:nth-child(even){
    background:#fafafa;
}

/* FINE BADGE */
.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    background:#e74c3c;
    color:white;
}

/* ENTRY/EXIT STYLE */
td:nth-child(4),
td:nth-child(5){
    color:#2c3e50;
    font-weight:500;
}

/* FINE AMOUNT EMPHASIS */
td:last-child{
    font-weight:bold;
    color:#c0392b;
    font-size:15px;
}
</style>

</head>

<body>

<div class="container">

<h2>💰 Fine Report</h2>

<table>
<tr>
<th>Visitor</th>
<th>Vehicle</th>
<th>Unit</th>
<th>Entry Time</th>
<th>Exit Time</th>
<th>Fine Amount</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>
<td><b><?php echo $row['visitor_name']; ?></b></td>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['unit_number']; ?></td>
<td><?php echo $row['entry_time']; ?></td>
<td><?php echo $row['exit_time'] ?: '—'; ?></td>

<td>
<span class="badge">₹ <?php echo $row['fine_amount']; ?></span>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>