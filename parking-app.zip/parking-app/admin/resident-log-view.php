<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT l.*, 
       v.vehicle_number,
       r.name,
       r.mobile,
       r.email,
       u.unit_number,
       w.wing_name,
       s.slot_number
FROM resident_parking_logs l
JOIN vehicles v ON l.vehicle_id = v.vehicle_id
JOIN residents r ON v.resident_id = r.resident_id
JOIN units u ON r.unit_id = u.unit_id
JOIN wings w ON u.wing_id = w.wing_id
JOIN parking_slots s ON l.slot_id = s.slot_id
WHERE l.log_id = $id
"));

$duration = "—";
if($data['exit_time']){
    $entry = strtotime($data['entry_time']);
    $exit = strtotime($data['exit_time']);
    $diff = $exit - $entry;
    $hours = floor($diff / 3600);
    $minutes = floor(($diff % 3600) / 60);
    $duration = $hours . " hrs " . $minutes . " mins";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>View Parking Log</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* CENTER */
.wrapper{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

/* CARD */
.card{
    width:560px;
    background:white;
    border-radius:18px;
    padding:30px;
    box-shadow:0 15px 35px rgba(0,0,0,0.12);
    position:relative;
}

/* TITLE */
h2{
    margin-top:0;
    text-align:center;
    color:#2c3e50;
}

/* ROW */
.row{
    display:flex;
    justify-content:space-between;
    padding:10px 0;
    border-bottom:1px solid #f1f1f1;
}

/* LABEL */
label{
    color:#7f8c8d;
    font-size:13px;
}

/* VALUE */
.value{
    font-weight:600;
    color:#2c3e50;
}

/* STATUS */
.status{
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.inside{
    background:#fdecea;
    color:#e74c3c;
}

.exited{
    background:#e8f8f0;
    color:#27ae60;
}

/* DURATION BOX */
.duration{
    text-align:center;
    margin-top:15px;
    padding:10px;
    background:#f4f6f9;
    border-radius:10px;
    font-weight:600;
}

/* BACK BUTTON */
a{
    display:block;
    text-align:center;
    margin-top:20px;
    text-decoration:none;
    background: linear-gradient(90deg,#3498db,#5dade2);
    color:white;
    padding:10px;
    border-radius:10px;
    font-weight:600;
}

a:hover{
    opacity:0.9;
}

/* TAG */
.tag{
    position:absolute;
    top:15px;
    right:15px;
    background:#2c3e50;
    color:white;
    padding:5px 10px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="wrapper">

<div class="card">

<div class="tag">LOG DETAILS</div>

<h2>🚗 Parking Entry Report</h2>

<div class="row"><label>Vehicle</label><div class="value"><?php echo $data['vehicle_number']; ?></div></div>
<div class="row"><label>Resident</label><div class="value"><?php echo $data['name']; ?></div></div>
<div class="row"><label>Mobile</label><div class="value"><?php echo $data['mobile']; ?></div></div>
<div class="row"><label>Email</label><div class="value"><?php echo $data['email']; ?></div></div>

<div class="row"><label>Wing</label><div class="value"><?php echo $data['wing_name']; ?></div></div>
<div class="row"><label>Unit</label><div class="value"><?php echo $data['unit_number']; ?></div></div>
<div class="row"><label>Slot</label><div class="value"><?php echo $data['slot_number']; ?></div></div>

<div class="row"><label>Entry Time</label><div class="value"><?php echo $data['entry_time']; ?></div></div>
<div class="row"><label>Exit Time</label><div class="value"><?php echo $data['exit_time'] ? $data['exit_time'] : "—"; ?></div></div>

<div class="row">
<label>Status</label>
<div class="value">
<span class="status <?php echo $data['exit_time'] ? 'exited' : 'inside'; ?>">
<?php echo $data['exit_time'] ? 'Exited' : 'Inside'; ?>
</span>
</div>
</div>

<div class="duration">
⏱ Duration: <?php echo $duration; ?>
</div>

<a href="resident-log-list.php">← Back to Logs</a>

</div>

</div>

</body>
</html>