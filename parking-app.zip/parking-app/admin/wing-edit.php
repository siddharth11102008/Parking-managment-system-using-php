<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM wings WHERE wing_id=$id"));

if(isset($_POST['update'])){
    $wing_name = $_POST['wing_name'];

    mysqli_query($conn,"UPDATE wings SET wing_name='$wing_name' WHERE wing_id=$id");

    header("Location: wing-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Wing</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER BOX */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:420px;
    background:white;
    padding:30px;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    color:#2c3e50;
    font-size:22px;
    text-align:center;
}

/* LABEL STYLE */
label{
    font-size:13px;
    color:#7f8c8d;
}

/* INPUT */
input{
    width:100%;
    padding:12px;
    margin-top:8px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    cursor:pointer;
    font-weight:600;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(243,156,18,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(243,156,18,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    color:#3498db;
    text-decoration:none;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* SMALL TAG STYLE */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#3498db;
    color:white;
    padding:5px 10px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">EDIT WING</div>

<h2>✏️ Update Wing</h2>

<form method="POST">

<label>Wing Name</label>
<input type="text" name="wing_name" value="<?php echo $data['wing_name']; ?>" required>

<button type="submit" name="update">Update Wing</button>

</form>

<a href="wing-list.php">← Back to Wing List</a>

</div>

</div>

</body>
</html>