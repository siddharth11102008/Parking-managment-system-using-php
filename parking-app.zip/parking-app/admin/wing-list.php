<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$result = mysqli_query($conn,"SELECT * FROM wings ORDER BY wing_id ASC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Wing List</title>

<style>
body{
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
    margin:0;
}

/* PAGE WRAPPER */
.container{
    width:90%;
    margin:40px auto;
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#2c3e50;
    font-size:22px;
}

/* TOP BAR */
.top{
    display:flex;
    justify-content:flex-end;
    margin-bottom:15px;
}

/* ADD BUTTON */
.add{
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    padding:10px 16px;
    text-decoration:none;
    border-radius:10px;
    font-size:14px;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
    transition:0.3s;
}

.add:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(46,204,113,0.4);
}

/* TABLE WRAPPER LOOK */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:14px;
    text-transform:uppercase;
    letter-spacing:0.5px;
}

td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
    color:#2c3e50;
}

/* ROW HOVER */
tr:hover{
    background:#f9fbff;
}

/* BUTTONS */
a{
    text-decoration:none;
    padding:8px 12px;
    border-radius:8px;
    font-size:13px;
    margin:0 3px;
    transition:0.3s;
}

/* EDIT */
.edit{
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
    box-shadow:0 4px 10px rgba(243,156,18,0.3);
}

.edit:hover{
    transform:translateY(-2px);
}

/* DELETE */
.delete{
    background: linear-gradient(90deg,#e74c3c,#ff6b6b);
    color:white;
    box-shadow:0 4px 10px rgba(231,76,60,0.3);
}

.delete:hover{
    transform:translateY(-2px);
}

/* EMPTY STATE */
.empty{
    text-align:center;
    padding:20px;
    color:#7f8c8d;
}
</style>

</head>

<body>

<div class="container">

<h2>🏢 Wings List</h2>

<div class="top">
    <a href="wing-add.php" class="add">+ Add Wing</a>
</div>

<div class="table-box">

<table>
<tr>
<th>Wing Name</th>
<th>Action</th>
</tr>

<?php if(mysqli_num_rows($result) > 0){ ?>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>
<td><?php echo $row['wing_name']; ?></td>
<td>
    <a href="wing-edit.php?id=<?php echo $row['wing_id']; ?>" class="edit">Edit</a>
    <a href="wing-delete.php?id=<?php echo $row['wing_id']; ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
</td>
</tr>
<?php } ?>

<?php } else { ?>
<tr>
<td colspan="2" class="empty">No wings found</td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>