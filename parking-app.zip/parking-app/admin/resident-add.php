<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$units = mysqli_query($conn,"SELECT u.unit_id, u.unit_number, w.wing_name 
FROM units u JOIN wings w ON u.wing_id=w.wing_id");

if(isset($_POST['save'])){
    $unit_id = $_POST['unit_id'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $type = $_POST['resident_type'];
    $status = $_POST['status'];

    mysqli_query($conn,"INSERT INTO residents(unit_id,name,mobile,email,resident_type,status)
    VALUES('$unit_id','$name','$mobile','$email','$type','$status')");

    header("Location: resident-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Resident</title>
<style>
body{font-family:Arial;background:#f4f6f9;}
.box{width:450px;margin:40px auto;background:white;padding:20px;}
input,select{width:100%;padding:8px;margin:8px 0;}
button{width:100%;padding:8px;background:#2c3e50;color:white;border:none;}
</style>
</head>
<body>

<div class="box">
<h2>Add Resident</h2>
<form method="POST">
<select name="unit_id" required>
<option value="">Select Wing - Unit</option>
<?php while($u=mysqli_fetch_assoc($units)){ ?>
<option value="<?php echo $u['unit_id']; ?>">
<?php echo $u['wing_name']." - ".$u['unit_number']; ?>
</option>
<?php } ?>
</select>

<input type="text" name="name" placeholder="Resident Name" required>
<input type="text" name="mobile" placeholder="Mobile">
<input type="email" name="email" placeholder="Email">

<select name="resident_type">
<option value="owner">Owner</option>
<option value="tenant">Tenant</option>
</select>

<select name="status">
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>

<button type="submit" name="save">Save</button>
</form>
<a href="resident-list.php">Back to List</a>
</div>

</body>
</html>
