<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$result = mysqli_query($conn,"
SELECT g.*, 
       u.unit_number,
       w.wing_name,
       s.slot_number
FROM guest_parking_logs g
JOIN units u ON g.visiting_unit_id = u.unit_id
JOIN wings w ON u.wing_id = w.wing_id
JOIN parking_slots s ON g.slot_id = s.slot_id
ORDER BY g.guest_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Guest Parking Logs</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* PAGE WRAPPER */
.container{
    width:94%;
    margin:35px auto;
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#2c3e50;
}

/* CARD TABLE */
.table-box{
    background:white;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:12px;
    text-transform:uppercase;
}

/* CELLS */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
    font-size:13px;
    color:#2c3e50;
}

/* HOVER */
tr:hover{
    background:#f8fbff;
}

/* STATUS */
.status{
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.inside{
    background:#fdecea;
    color:#e74c3c;
}

.exited{
    background:#e8f8f0;
    color:#27ae60;
}

/* BUTTONS */
a{
    text-decoration:none;
    padding:6px 10px;
    border-radius:8px;
    font-size:12px;
    display:inline-block;
    transition:0.3s;
}

/* VIEW */
.view{
    background: linear-gradient(90deg,#3498db,#5dade2);
    color:white;
}

/* DELETE */
.delete{
    background: linear-gradient(90deg,#e74c3c,#ec7063);
    color:white;
}

/* FINE BADGE */
.fine{
    background:#fff3cd;
    color:#b8860b;
    padding:5px 10px;
    border-radius:20px;
    font-weight:600;
}

/* TABLE WRAP */
.table-box{
    overflow-x:auto;
}
</style>

</head>

<body>

<div class="container">

<h2>🚗 Guest Parking Monitoring Logs</h2>

<div class="table-box">

<table>

<tr>
<th>Visitor</th>
<th>Mobile</th>
<th>Vehicle</th>
<th>Wing</th>
<th>Unit</th>
<th>Slot</th>
<th>Entry</th>
<th>Exit</th>
<th>Fine</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>

<td><b><?php echo $row['visitor_name']; ?></b></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['wing_name']; ?></td>
<td><?php echo $row['unit_number']; ?></td>

<td><b><?php echo $row['slot_number']; ?></b></td>

<td><?php echo $row['entry_time']; ?></td>
<td><?php echo $row['exit_time'] ? $row['exit_time'] : "—"; ?></td>

<td>
<span class="fine">₹ <?php echo number_format($row['fine_amount'],2); ?></span>
</td>

<td>
<span class="status <?php echo $row['exit_time'] ? 'exited' : 'inside'; ?>">
<?php echo $row['exit_time'] ? 'Exited' : 'Inside'; ?>
</span>
</td>

<td>
<a href="guest-log-view.php?id=<?php echo $row['guest_id']; ?>" class="view">View</a>

<a href="guest-log-delete.php?id=<?php echo $row['guest_id']; ?>" 
   class="delete"
   onclick="return confirm('Delete this log?')">
Delete
</a>
</td>

</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>