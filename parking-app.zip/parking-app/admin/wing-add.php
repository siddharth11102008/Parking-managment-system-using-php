<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

if(isset($_POST['save'])){
    $wing_name = $_POST['wing_name'];

    mysqli_query($conn,"INSERT INTO wings(wing_name) VALUES('$wing_name')");

    header("Location: wing-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Wing</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER LAYOUT */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:420px;
    background:#fff;
    padding:30px;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
    font-size:22px;
}

/* LABEL STYLE */
label{
    font-size:13px;
    color:#7f8c8d;
}

/* INPUT */
input{
    width:100%;
    padding:12px;
    margin-top:8px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(46,204,113,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    color:#3498db;
    text-decoration:none;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#2ecc71;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">ADD WING</div>

<h2>🏢 Create New Wing</h2>

<form method="POST">

<label>Wing Name</label>
<input type="text" name="wing_name" placeholder="Enter Wing Name" required>

<button type="submit" name="save">Save Wing</button>

</form>

<a href="wing-list.php">← Back to Wing List</a>

</div>

</div>

</body>
</html>