<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];

mysqli_query($conn,"DELETE FROM guest_parking_logs WHERE guest_id=$id");

header("Location: guest-log-list.php");
exit();
?>
