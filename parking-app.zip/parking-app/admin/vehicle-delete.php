<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM vehicles WHERE vehicle_id=$id");

header("Location: vehicle-list.php");
exit();
?>
