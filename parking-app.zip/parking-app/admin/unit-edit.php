<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM units WHERE unit_id=$id"));
$wings = mysqli_query($conn,"SELECT * FROM wings ORDER BY wing_name ASC");

if(isset($_POST['update'])){
    $wing_id = $_POST['wing_id'];
    $unit_number = $_POST['unit_number'];
    $floor_number = $_POST['floor_number'];

    mysqli_query($conn,"UPDATE units 
        SET wing_id='$wing_id', unit_number='$unit_number', floor_number='$floor_number' 
        WHERE unit_id=$id");

    header("Location: unit-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Unit</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER LAYOUT */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:450px;
    background:white;
    padding:30px;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
}

/* LABEL */
label{
    font-size:13px;
    color:#7f8c8d;
    display:block;
    margin-top:10px;
}

/* INPUT & SELECT */
input,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus,select:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    margin-top:15px;
    padding:12px;
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    border:none;
    border-radius:10px;
    color:white;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(243,156,18,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(243,156,18,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    color:#3498db;
    text-decoration:none;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#3498db;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">EDIT UNIT</div>

<h2>🏢 Update Unit</h2>

<form method="POST">

<label>Wing</label>
<select name="wing_id" required>
<option value="">Select Wing</option>
<?php while($w=mysqli_fetch_assoc($wings)){ ?>
<option value="<?php echo $w['wing_id']; ?>" 
<?php if($data['wing_id']==$w['wing_id']) echo 'selected'; ?>>
<?php echo $w['wing_name']; ?>
</option>
<?php } ?>
</select>

<label>Unit Number</label>
<input type="text" name="unit_number" value="<?php echo $data['unit_number']; ?>" required>

<label>Floor Number</label>
<input type="number" name="floor_number" value="<?php echo $data['floor_number']; ?>" required>

<button type="submit" name="update">Update Unit</button>

</form>

<a href="unit-list.php">← Back to Units List</a>

</div>

</div>

</body>
</html>