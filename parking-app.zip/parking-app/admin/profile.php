<?php include 'admin-header.php'; ?>

<!DOCTYPE html>
<html>
<head>
<title>My Profile</title>

<style>

/* ONLY PAGE BACKGROUND */
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background:linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* CONTAINER */
.profile-container{
    display:flex;
    justify-content:center;
    margin-top:40px;
}

/* PROFILE CARD */
.profile-card{
    width:420px;
    background:#fff;
    padding:35px 30px;
    border-radius:20px;
    box-shadow:0 20px 40px rgba(0,0,0,0.12);
    text-align:center;
    position:relative;
    transition:0.3s;
}

.profile-card:hover{
    transform:translateY(-5px);
}

/* AVATAR */
.profile-card .avatar{
    width:90px;
    height:90px;
    background:linear-gradient(135deg,#3498db,#2980b9);
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:32px;
    color:white;
    margin:0 auto 15px;
}

/* TITLE */
.profile-card h2{
    margin:10px 0 20px;
    color:#2c3e50;
}

/* INFO ROW */
.profile-card .row{
    background:#f8fbff;
    padding:12px 15px;
    margin-bottom:10px;
    border-radius:10px;
    border-left:4px solid #3498db;
    font-size:14px;
    display:flex;
    justify-content:space-between;
}

/* LABEL */
.profile-card .label{
    color:#7f8c8d;
}

/* VALUE */
.profile-card .value{
    font-weight:600;
    color:#2c3e50;
}

/* ROLE BADGE */
.profile-card .role{
    background:#2ecc71;
    color:white;
    padding:4px 10px;
    border-radius:20px;
    font-size:12px;
}

/* BUTTON (IMPORTANT: scoped!) */
.profile-card a{
    display:inline-block;
    margin-top:20px;
    padding:12px 18px;
    background:linear-gradient(90deg,#3498db,#2980b9);
    color:white;
    text-decoration:none;
    border-radius:10px;
    font-weight:600;
    transition:0.3s;
}

.profile-card a:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(52,152,219,0.3);
}

/* TAG */
.profile-card .tag{
    position:absolute;
    top:-12px;
    left:20px;
    background:#9b59b6;
    color:white;
    padding:5px 12px;
    border-radius:20px;
    font-size:12px;
}

</style>
</head>

<body>

<div class="profile-container">

<div class="profile-card">

<div class="tag">PROFILE</div>

<div class="avatar">
<?php echo strtoupper(substr($_SESSION['admin'],0,1)); ?>
</div>

<h2><?php echo $_SESSION['admin']; ?></h2>

<div class="row">
<span class="label">Username</span>
<span class="value"><?php echo $_SESSION['admin']; ?></span>
</div>

<div class="row">
<span class="label">Email</span>
<span class="value">admin@example.com</span>
</div>

<div class="row">
<span class="label">Role</span>
<span class="value"><span class="role">Administrator</span></span>
</div>

<a href="admin-dashboard.php">← Back to Dashboard</a>

</div>

</div>

</body>
</html>