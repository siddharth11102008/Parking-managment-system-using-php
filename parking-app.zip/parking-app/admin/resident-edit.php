<?php
$conn = mysqli_connect("localhost","root","","parking_db");

$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM residents WHERE resident_id=$id"));

$units = mysqli_query($conn,"
SELECT u.unit_id, u.unit_number, w.wing_name 
FROM units u 
JOIN wings w ON u.wing_id=w.wing_id
");

if(isset($_POST['update'])){
    $unit_id = $_POST['unit_id'];
    $name = $_POST['name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $type = $_POST['resident_type'];
    $status = $_POST['status'];

    mysqli_query($conn,"UPDATE residents SET 
        unit_id='$unit_id',
        name='$name',
        mobile='$mobile',
        email='$email',
        resident_type='$type',
        status='$status'
        WHERE resident_id=$id
    ");

    header("Location: resident-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Resident</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER WRAPPER */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:520px;
    background:#fff;
    padding:30px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
}

/* LABEL */
label{
    font-size:13px;
    color:#7f8c8d;
    display:block;
    margin-top:10px;
}

/* INPUT + SELECT */
input,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    margin-bottom:12px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
    background:#fff;
}

input:focus,select:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#f39c12,#f1c40f);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(243,156,18,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(243,156,18,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#3498db;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#3498db;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">EDIT RESIDENT</div>

<h2>👤 Update Resident</h2>

<form method="POST">

<label>Select Unit</label>
<select name="unit_id" required>
<?php while($u=mysqli_fetch_assoc($units)){ ?>
<option value="<?php echo $u['unit_id']; ?>"
<?php if($data['unit_id']==$u['unit_id']) echo "selected"; ?>>
<?php echo $u['wing_name']." - ".$u['unit_number']; ?>
</option>
<?php } ?>
</select>

<label>Name</label>
<input type="text" name="name" value="<?php echo $data['name']; ?>" required>

<label>Mobile</label>
<input type="text" name="mobile" value="<?php echo $data['mobile']; ?>">

<label>Email</label>
<input type="email" name="email" value="<?php echo $data['email']; ?>">

<label>Resident Type</label>
<select name="resident_type">
<option value="owner" <?php if($data['resident_type']=="owner") echo "selected"; ?>>Owner</option>
<option value="tenant" <?php if($data['resident_type']=="tenant") echo "selected"; ?>>Tenant</option>
</select>

<label>Status</label>
<select name="status">
<option value="active" <?php if($data['status']=="active") echo "selected"; ?>>Active</option>
<option value="inactive" <?php if($data['status']=="inactive") echo "selected"; ?>>Inactive</option>
</select>

<button type="submit" name="update">Update Resident</button>

</form>

<a href="resident-list.php">← Back to List</a>

</div>

</div>

</body>
</html>