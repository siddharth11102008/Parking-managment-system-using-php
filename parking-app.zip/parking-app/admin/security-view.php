
<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$id = (int)$_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT * FROM users 
    WHERE user_id=$id AND role='security'
"));

if(!$data){
    die("Security Not Found");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>View Security</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

/* Container */
.container{
    width:420px;
    margin:60px auto;
}

/* Card */
.box{
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    text-align:center;
    animation:fadeIn 0.4s ease;
}

/* Avatar Circle */
.avatar{
    width:80px;
    height:80px;
    border-radius:50%;
    background:linear-gradient(45deg,#2c3e50,#34495e);
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:28px;
    font-weight:bold;
    margin:0 auto 15px;
}

/* Name */
.name{
    font-size:20px;
    font-weight:bold;
    color:#2c3e50;
    margin-bottom:5px;
}

/* Email */
.email{
    font-size:14px;
    color:#777;
    margin-bottom:20px;
}

/* Info Box */
.info{
    text-align:left;
    margin-top:10px;
}

.info p{
    padding:10px;
    border-bottom:1px solid #eee;
    font-size:14px;
}

/* Label */
.info b{
    color:#2c3e50;
}

/* Status Badge */
.status{
    display:inline-block;
    padding:5px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:bold;
    color:white;
}

.active{
    background:#27ae60;
}

.inactive{
    background:#e74c3c;
}

/* Back Button */
.back{
    display:inline-block;
    margin-top:20px;
    padding:10px 15px;
    background:linear-gradient(45deg,#3498db,#5dade2);
    color:white;
    text-decoration:none;
    border-radius:25px;
    font-size:14px;
    transition:0.3s;
}

.back:hover{
    background:linear-gradient(45deg,#2e86c1,#3498db);
}

/* Animation */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(15px);}
    to{opacity:1; transform:translateY(0);}
}

/* Mobile */
@media(max-width:480px){
    .container{
        width:90%;
        margin:30px auto;
    }
}
</style>

</head>
<body>

<div class="container">

<div class="box">

<div class="avatar">
<?php echo strtoupper(substr($data['name'],0,1)); ?>
</div>

<div class="name"><?php echo $data['name']; ?></div>
<div class="email"><?php echo $data['email']; ?></div>

<div class="info">
<p><b>ID:</b> <?php echo $data['user_id']; ?></p>
<p><b>Mobile:</b> <?php echo $data['mobile']; ?></p>
<p><b>Status:</b> 
    <span class="status <?php echo $data['status']=='active' ? 'active' : 'inactive'; ?>">
        <?php echo ucfirst($data['status']); ?>
    </span>
</p>
</div>

<a href="security-list.php" class="back">← Back to List</a>

</div>

</div>

</body>
</html>