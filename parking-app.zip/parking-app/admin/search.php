<?php
include("admin-header.php");
$conn = mysqli_connect("localhost","root","","parking_db");

$result = null;
$keyword = "";

if(isset($_POST['search'])){
    $keyword = mysqli_real_escape_string($conn, $_POST['keyword']);

    $result = mysqli_query($conn,"
        SELECT * FROM guest_parking_logs
        WHERE visitor_name LIKE '%$keyword%'
        OR vehicle_number LIKE '%$keyword%'
        ORDER BY guest_id DESC
    ");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Search Records</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background:linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* CONTAINER */
.container{
    width:92%;
    margin:35px auto;
}

/* TITLE */
h2{
    color:#2c3e50;
    margin-bottom:15px;
}

/* SEARCH BOX CARD */
.search-box{
    background:white;
    padding:20px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    display:flex;
    gap:10px;
    align-items:center;
    flex-wrap:wrap;
    margin-bottom:20px;
}

input{
    flex:1;
    min-width:250px;
    padding:12px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

button{
    padding:12px 18px;
    background:linear-gradient(90deg,#3498db,#2980b9);
    border:none;
    color:white;
    border-radius:10px;
    cursor:pointer;
    font-weight:600;
    transition:0.3s;
}

button:hover{
    transform:translateY(-2px);
}

/* TABLE WRAP */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background:linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:12px;
    text-transform:uppercase;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
}

/* HOVER */
tr:hover{
    background:#f8fbff;
}

/* STATUS */
.status-inside{
    color:#e67e22;
    font-weight:600;
}

.status-exited{
    color:#2ecc71;
    font-weight:600;
}

/* EMPTY STATE */
.empty{
    text-align:center;
    padding:20px;
    color:#7f8c8d;
}
</style>
</head>

<body>

<div class="container">

<h2>🔍 Search Guest Records</h2>

<form method="POST" class="search-box">
    <input type="text" name="keyword" placeholder="Search by visitor name or vehicle number..." value="<?php echo htmlspecialchars($keyword); ?>" required>
    <button type="submit" name="search">Search</button>
</form>

<?php if($result){ ?>

<div class="table-box">
<table>
<tr>
<th>Visitor</th>
<th>Vehicle</th>
<th>Entry Time</th>
<th>Exit Time</th>
<th>Status</th>
</tr>

<?php if(mysqli_num_rows($result) > 0){ ?>
    <?php while($row=mysqli_fetch_assoc($result)){ ?>
    <tr>
        <td><?php echo $row['visitor_name']; ?></td>
        <td><?php echo $row['vehicle_number']; ?></td>
        <td><?php echo $row['entry_time']; ?></td>
        <td><?php echo $row['exit_time'] ? $row['exit_time'] : "—"; ?></td>
        <td class="<?php echo $row['exit_time'] ? 'status-exited' : 'status-inside'; ?>">
            <?php echo $row['exit_time'] ? 'Exited' : 'Inside'; ?>
        </td>
    </tr>
    <?php } ?>
<?php } else { ?>
    <tr>
        <td colspan="5" class="empty">No records found</td>
    </tr>
<?php } ?>

</table>
</div>

<?php } ?>

</div>

</body>
</html>