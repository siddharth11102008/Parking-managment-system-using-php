<?php include 'admin-header.php'; ?>

<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$result = mysqli_query($conn,"
SELECT l.*, 
       v.vehicle_number,
       r.name,
       u.unit_number,
       w.wing_name,
       s.slot_number
FROM resident_parking_logs l
JOIN vehicles v ON l.vehicle_id = v.vehicle_id
JOIN residents r ON v.resident_id = r.resident_id
JOIN units u ON r.unit_id = u.unit_id
JOIN wings w ON u.wing_id = w.wing_id
JOIN parking_slots s ON l.slot_id = s.slot_id
ORDER BY l.log_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Resident Parking Logs</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* PAGE */
.container{
    width:92%;
    margin:40px auto;
}

/* TITLE */
h2{
    margin-bottom:15px;
    color:#2c3e50;
}

/* TABLE CARD */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:12px;
    text-transform:uppercase;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
    color:#2c3e50;
}

/* HOVER */
tr:hover{
    background:#f9fbff;
}

/* BUTTON */
a{
    text-decoration:none;
    padding:6px 10px;
    border-radius:8px;
    font-size:12px;
    display:inline-block;
    transition:0.3s;
}

/* VIEW */
.view{
    background: linear-gradient(90deg,#3498db,#5dade2);
    color:white;
}

/* STATUS BADGES */
.status{
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

/* INSIDE */
.inside{
    background:#fdecea;
    color:#e74c3c;
}

/* EXITED */
.exited{
    background:#e8f8f0;
    color:#27ae60;
}

/* SLOT BADGE */
.slot{
    background:#ecf0f1;
    padding:5px 10px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}
</style>

</head>

<body>

<div class="container">

<h2>🚗 Resident Parking Activity Logs</h2>

<div class="table-box">

<table>

<tr>
<th>Vehicle</th>
<th>Resident</th>
<th>Wing</th>
<th>Unit</th>
<th>Slot</th>
<th>Entry Time</th>
<th>Exit Time</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>

<td><strong><?php echo $row['vehicle_number']; ?></strong></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['wing_name']; ?></td>
<td><?php echo $row['unit_number']; ?></td>

<td><span class="slot"><?php echo $row['slot_number']; ?></span></td>

<td><?php echo $row['entry_time']; ?></td>
<td><?php echo $row['exit_time'] ? $row['exit_time'] : "—"; ?></td>

<td>
<span class="status <?php echo $row['exit_time'] ? 'exited' : 'inside'; ?>">
<?php echo $row['exit_time'] ? 'Exited' : 'Inside'; ?>
</span>
</td>

<td>
<a href="resident-log-view.php?id=<?php echo $row['log_id']; ?>" class="view">View</a>
</td>

</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>