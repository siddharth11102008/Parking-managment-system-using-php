<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$id=$_GET['id'];

mysqli_query($conn,"DELETE FROM users WHERE user_id=$id AND role='security'");

header("Location: security-list.php");
exit();
?>
