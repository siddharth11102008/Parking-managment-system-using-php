<?php
include("admin-header.php");
$conn = mysqli_connect("localhost","root","","parking_db");

$result = mysqli_query($conn,"
    SELECT DATE(entry_time) as date, COUNT(*) as total
    FROM guest_parking_logs
    GROUP BY DATE(entry_time)
    ORDER BY date DESC
");

$totalToday = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) as t FROM guest_parking_logs 
    WHERE DATE(entry_time)=CURDATE()
"))['t'];

$totalAll = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) as t FROM guest_parking_logs
"))['t'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Daily Report</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(135deg,#eef2f7,#f7f9fc);
}

/* MAIN WRAPPER */
.container{
    width:92%;
    margin:35px auto;
}

/* TITLE */
h2{
    color:#2c3e50;
    margin-bottom:20px;
    font-size:22px;
}

/* DASH CARDS */
.cards{
    display:flex;
    gap:20px;
    flex-wrap:wrap;
    margin-bottom:25px;
}

.card{
    flex:1;
    min-width:220px;
    background:white;
    padding:20px;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-6px);
}

.card h3{
    margin:0;
    font-size:13px;
    color:#7f8c8d;
    text-transform:uppercase;
}

.card p{
    margin-top:10px;
    font-size:26px;
    font-weight:bold;
    color:#2c3e50;
}

/* CARD COLORS */
.blue{border-left:5px solid #3498db;}
.green{border-left:5px solid #2ecc71;}
.orange{border-left:5px solid #f39c12;}

/* TABLE BOX */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background:linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:12px;
    text-transform:uppercase;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
}

/* HOVER */
tr:hover{
    background:#f8fbff;
}

/* BADGE */
.badge{
    display:inline-block;
    padding:5px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    background:#ecf0f1;
    color:#2c3e50;
}

/* HIGH TRAFFIC BADGE */
.high{
    background:#e74c3c;
    color:white;
}

/* NORMAL BADGE */
.normal{
    background:#2ecc71;
    color:white;
}
</style>

</head>

<body>

<div class="container">

<h2>📅 Daily Parking Analytics Report</h2>

<!-- CARDS -->
<div class="cards">

<div class="card blue">
<h3>Today Entries</h3>
<p><?php echo $totalToday; ?></p>
</div>

<div class="card green">
<h3>Total Entries</h3>
<p><?php echo $totalAll; ?></p>
</div>

<div class="card orange">
<h3>Active Days</h3>
<p><?php echo mysqli_num_rows($result); ?></p>
</div>

</div>

<!-- TABLE -->
<div class="table-box">

<table>
<tr>
<th>Date</th>
<th>Total Entries</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>
<td><b><?php echo $row['date']; ?></b></td>
<td><?php echo $row['total']; ?></td>

<td>
<?php if($row['total'] > 10){ ?>
    <span class="badge high">High Traffic</span>
<?php } else { ?>
    <span class="badge normal">Normal</span>
<?php } ?>
</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>
</html>