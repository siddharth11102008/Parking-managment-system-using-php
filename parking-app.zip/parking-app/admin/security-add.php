
<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

if(isset($_POST['save'])){
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $mobile   = $_POST['mobile'];
    $status   = $_POST['status'];

    mysqli_query($conn,"INSERT INTO users(name,email,password,role,mobile,status)
    VALUES('$name','$email','$password','security','$mobile','$status')");

    header("Location: security-list.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Security Staff</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

/* Container */
.container{
    width:420px;
    margin:60px auto;
}

/* Card */
.box{
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    animation:fadeIn 0.4s ease;
}

/* Heading */
h2{
    text-align:center;
    margin-bottom:20px;
    color:#2c3e50;
}

/* Inputs */
input, select{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:14px;
    transition:0.3s;
}

input:focus, select:focus{
    border-color:#2c3e50;
    outline:none;
    box-shadow:0 0 6px rgba(44,62,80,0.2);
}

/* Button */
button{
    width:100%;
    padding:12px;
    background:linear-gradient(45deg,#2c3e50,#34495e);
    color:white;
    border:none;
    border-radius:25px;
    cursor:pointer;
    font-size:15px;
    font-weight:bold;
    transition:0.3s;
}

button:hover{
    background:linear-gradient(45deg,#1a252f,#2c3e50);
}

/* Back Button */
.back{
    display:block;
    margin-top:15px;
    text-align:center;
    text-decoration:none;
    color:#2c3e50;
    font-weight:bold;
    transition:0.3s;
}

.back:hover{
    color:#3498db;
}

/* Animation */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(15px);}
    to{opacity:1; transform:translateY(0);}
}

/* Mobile */
@media(max-width:480px){
    .container{
        width:90%;
        margin:30px auto;
    }
}
</style>

</head>
<body>

<div class="container">

<div class="box">

<h2>👮 Add Security Staff</h2>

<form method="POST">

<input type="text" name="name" placeholder="Full Name" required>

<input type="email" name="email" placeholder="Email Address" required>

<input type="text" name="password" placeholder="Password" required>

<input type="text" name="mobile" placeholder="Mobile Number" required>

<select name="status">
<option value="active">Active</option>
<option value="inactive">Inactive</option>
</select>

<button type="submit" name="save">Save Security</button>

</form>

<a href="security-list.php" class="back">← Back to List</a>

</div>

</div>

</body>
</html>