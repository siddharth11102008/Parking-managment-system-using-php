<?php
$conn = mysqli_connect("localhost","root","","parking_db");

if(isset($_POST['save'])){
    $slot_number = $_POST['slot_number'];
    $slot_type = $_POST['slot_type'];
    $status = $_POST['status'];

    mysqli_query($conn,"INSERT INTO parking_slots(slot_number,slot_type,status)
    VALUES('$slot_number','$slot_type','$status')");

    header("Location: slot-list.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Slot</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* CENTER */
.container{
    width:100%;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.box{
    width:420px;
    background:#fff;
    padding:30px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
    position:relative;
}

/* TITLE */
.box h2{
    margin:0 0 20px;
    text-align:center;
    color:#2c3e50;
}

/* LABEL */
label{
    font-size:13px;
    color:#7f8c8d;
    display:block;
    margin-top:10px;
}

/* INPUT + SELECT */
input,select{
    width:100%;
    padding:12px;
    margin-top:6px;
    margin-bottom:12px;
    border:1px solid #ddd;
    border-radius:10px;
    font-size:14px;
    transition:0.3s;
}

input:focus,select:focus{
    outline:none;
    border-color:#3498db;
    box-shadow:0 0 8px rgba(52,152,219,0.2);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background: linear-gradient(90deg,#2ecc71,#27ae60);
    color:white;
    border:none;
    border-radius:10px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    box-shadow:0 6px 15px rgba(46,204,113,0.3);
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(46,204,113,0.4);
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#3498db;
    font-size:13px;
}

a:hover{
    text-decoration:underline;
}

/* TAG */
.tag{
    position:absolute;
    top:-10px;
    left:20px;
    background:#2ecc71;
    color:white;
    padding:5px 12px;
    font-size:12px;
    border-radius:20px;
}
</style>

</head>

<body>

<div class="container">

<div class="box">

<div class="tag">ADD SLOT</div>

<h2>🅿️ Create Parking Slot</h2>

<form method="POST">

<label>Slot Number</label>
<input type="text" name="slot_number" placeholder="e.g. R-16 / G-05" required>

<label>Slot Type</label>
<select name="slot_type">
<option value="resident">Resident</option>
<option value="guest">Guest</option>
</select>

<label>Status</label>
<select name="status">
<option value="available">Available</option>
<option value="occupied">Occupied</option>
<option value="reserved">Reserved</option>
<option value="blocked">Blocked</option>
</select>

<button type="submit" name="save">Save Slot</button>

</form>

<a href="slot-list.php">← Back to Slot List</a>

</div>

</div>

</body>
</html>