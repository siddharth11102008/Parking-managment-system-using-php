<?php
session_start();

if(!isset($_SESSION['admin'])){
    header("Location: admin-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}

if(isset($_POST['assign'])){
    $slot_id = $_POST['slot_id'];
    $resident_id = $_POST['resident_id'];

    $check = mysqli_query($conn,"SELECT assigned_resident_id FROM parking_slots WHERE slot_id='$slot_id'");
    $data = mysqli_fetch_assoc($check);

    if($data['assigned_resident_id'] != NULL){
        $msg = "⚠ Slot already assigned!";
    } else {
        mysqli_query($conn,"UPDATE parking_slots 
            SET assigned_resident_id='$resident_id', status='reserved'
            WHERE slot_id='$slot_id'
        ");
        $msg = "✅ Slot Assigned Successfully!";
    }
}

$residents = mysqli_query($conn,"
SELECT r.resident_id, r.name, u.unit_number, w.wing_name
FROM residents r
JOIN units u ON r.unit_id = u.unit_id
JOIN wings w ON u.wing_id = w.wing_id
WHERE r.status='active'
");

$slots = mysqli_query($conn,"
SELECT * FROM parking_slots 
WHERE slot_type='resident'
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Assign Parking Slot</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', Arial;
    background: linear-gradient(180deg,#f7f9fc,#eef2f7);
}

/* PAGE WRAPPER */
.container{
    width:92%;
    margin:40px auto;
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.header h2{
    margin:0;
    color:#2c3e50;
}

/* BACK BUTTON */
.back-btn{
    text-decoration:none;
    background:#34495e;
    color:white;
    padding:8px 14px;
    border-radius:8px;
    font-size:13px;
    transition:0.3s;
}

.back-btn:hover{
    background:#2c3e50;
}

/* MESSAGE */
.msg{
    padding:10px 15px;
    border-radius:10px;
    margin-bottom:15px;
    font-weight:600;
    background:#e8f8f0;
    color:#27ae60;
}

/* TABLE CARD */
.table-box{
    background:white;
    border-radius:16px;
    overflow:hidden;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

/* HEADER */
th{
    background: linear-gradient(90deg,#2c3e50,#34495e);
    color:white;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
}

/* ROW */
td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #f1f1f1;
}

/* HOVER */
tr:hover{
    background:#f9fbff;
}

/* SELECT */
select{
    padding:10px;
    border-radius:8px;
    border:1px solid #ddd;
    outline:none;
}

/* BUTTON */
.btn{
    padding:8px 14px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    color:white;
    background: linear-gradient(90deg,#3498db,#5dade2);
    font-size:12px;
    margin-left:6px;
    transition:0.3s;
}

.btn:hover{
    transform:translateY(-2px);
}

/* STATUS */
.available{
    color:#27ae60;
    font-weight:600;
}

.reserved{
    color:#f39c12;
    font-weight:600;
}

.occupied{
    color:#e74c3c;
    font-weight:600;
}

/* FORM ROW */
.form-row{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
}
</style>

</head>

<body>

<div class="container">

<div class="header">
    <h2>🚗 Assign Parking Slots</h2>
    <a href="slot-list.php" class="back-btn">← Back</a>
</div>

<?php if(isset($msg)) echo "<div class='msg'>$msg</div>"; ?>

<div class="table-box">

<table>

<tr>
<th>Slot Number</th>
<th>Status</th>
<th>Assign Resident</th>
</tr>

<?php while($row = mysqli_fetch_assoc($slots)){ ?>
<tr>

<form method="POST">

<td><strong><?php echo $row['slot_number']; ?></strong></td>

<td class="<?php echo $row['status']; ?>">
<?php echo ucfirst($row['status']); ?>
</td>

<td>

<div class="form-row">

<input type="hidden" name="slot_id" value="<?php echo $row['slot_id']; ?>">

<select name="resident_id" required>
<option value="">Select Resident</option>

<?php 
mysqli_data_seek($residents, 0);
while($r = mysqli_fetch_assoc($residents)){ ?>
<option value="<?php echo $r['resident_id']; ?>">
<?php echo $r['name']." (".$r['wing_name']." - ".$r['unit_number'].")"; ?>
</option>
<?php } ?>

</select>

<button class="btn" name="assign">Assign</button>

</div>

</td>

</form>

</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>