<?php
$conn = mysqli_connect("localhost","root","","parking_db");
if(!$conn){ die("Connection Failed: " . mysqli_connect_error()); }

$id = $_GET['id'];
mysqli_query($conn,"DELETE FROM wings WHERE wing_id=$id");

header("Location: wing-list.php");
exit();
?>
