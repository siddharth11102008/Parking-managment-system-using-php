<?php
session_start();

$conn = mysqli_connect("localhost","root","","parking_db");

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}

include("security-header.php");

// ================= ENTRY =================
if(isset($_GET['entry'])){
    $vehicle_id = (int)$_GET['entry'];

    // Check already inside
    $check = mysqli_query($conn,"
        SELECT * FROM resident_parking_logs 
        WHERE vehicle_id='$vehicle_id' AND exit_time IS NULL
    ");

    if(mysqli_num_rows($check) > 0){
        $msg = "Vehicle already inside!";
    } else {

        // Get available slot
        $slot = mysqli_fetch_assoc(mysqli_query($conn,"
            SELECT * FROM parking_slots 
            WHERE slot_type='resident' AND status='available' 
            LIMIT 1
        "));

        if($slot){

            mysqli_query($conn,"
                INSERT INTO resident_parking_logs
                (vehicle_id, slot_id, entry_time, created_by)
                VALUES ($vehicle_id, {$slot['slot_id']}, NOW(), {$_SESSION['security_id']})
            ");

            mysqli_query($conn,"
                UPDATE parking_slots 
                SET status='occupied' 
                WHERE slot_id={$slot['slot_id']}
            ");

            $msg = "Entry Successful!";
        } else {
            $msg = "No Slot Available!";
        }
    }
}

// ================= EXIT =================
if(isset($_GET['exit'])){
    $vehicle_id = (int)$_GET['exit'];

    $log = mysqli_fetch_assoc(mysqli_query($conn,"
        SELECT * FROM resident_parking_logs 
        WHERE vehicle_id='$vehicle_id' AND exit_time IS NULL
    "));

    if($log){

        mysqli_query($conn,"
            UPDATE resident_parking_logs 
            SET exit_time = NOW() 
            WHERE log_id = {$log['log_id']}
        ");

        mysqli_query($conn,"
            UPDATE parking_slots 
            SET status='available' 
            WHERE slot_id = {$log['slot_id']}
        ");

        $msg = "Exit Successful!";
    } else {
        $msg = "Vehicle already outside!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Resident Entry Exit</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

/* Container */
.box{
    width:95%;
    margin:30px auto;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 25px rgba(0,0,0,0.1);
    animation:fadeIn 0.4s ease-in-out;
}

/* Heading */
h2{
    margin-bottom:20px;
    color:#2c3e50;
    border-left:5px solid #3498db;
    padding-left:10px;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:10px;
}

/* Header */
th{
    background:linear-gradient(45deg,#2c3e50,#34495e);
    color:white;
    padding:12px;
    font-size:14px;
}

/* Cells */
td{
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:center;
    font-size:14px;
}

/* Zebra */
tr:nth-child(even){
    background:#f9fbfc;
}

/* Hover effect */
tr:hover{
    background:#eef5ff;
    transition:0.2s;
}

/* Buttons */
.btn-entry{
    padding:6px 14px;
    background:linear-gradient(45deg,#27ae60,#2ecc71);
    color:white;
    text-decoration:none;
    border-radius:20px;
    font-size:13px;
    transition:0.3s;
}

.btn-entry:hover{
    background:linear-gradient(45deg,#1e8449,#27ae60);
}

.btn-exit{
    padding:6px 14px;
    background:linear-gradient(45deg,#e74c3c,#ff6b6b);
    color:white;
    text-decoration:none;
    border-radius:20px;
    font-size:13px;
    transition:0.3s;
}

.btn-exit:hover{
    background:linear-gradient(45deg,#c0392b,#e74c3c);
}

/* Status */
.inside{
    color:#27ae60;
    font-weight:bold;
}

.outside{
    color:#e74c3c;
    font-weight:bold;
}

/* Message */
.msg{
    padding:12px;
    background:#d4edda;
    color:#155724;
    margin-bottom:15px;
    border-radius:6px;
    border-left:5px solid #28a745;
}

/* Animation */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(10px);}
    to{opacity:1; transform:translateY(0);}
}

/* Responsive */
@media(max-width:768px){
    table,thead,tbody,th,td,tr{
        display:block;
    }

    th{
        display:none;
    }

    tr{
        margin-bottom:10px;
        background:white;
        border-radius:10px;
        padding:10px;
        box-shadow:0 5px 10px rgba(0,0,0,0.05);
    }

    td{
        text-align:left;
        padding:8px;
        border:none;
    }

    td:before{
        content:attr(data-label);
        font-weight:bold;
        display:block;
        color:#555;
    }
}
</style>
</head>

<body>

<div class="box">

<h2>🚗 Resident Entry / Exit Panel</h2>

<?php if(isset($msg)) echo "<div class='msg'>$msg</div>"; ?>

<table>
<tr>
<th>Resident</th>
<th>Vehicle</th>
<th>Type</th>
<th>Wing</th>
<th>Unit</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php
$q = mysqli_query($conn,"
    SELECT v.vehicle_id, v.vehicle_number, v.vehicle_type,
           r.name, u.unit_number, w.wing_name
    FROM vehicles v
    JOIN residents r ON v.resident_id = r.resident_id
    JOIN units u ON r.unit_id = u.unit_id
    JOIN wings w ON u.wing_id = w.wing_id
    WHERE r.status='active'
");

while($row = mysqli_fetch_assoc($q)){

    // Check if inside
    $inside = mysqli_query($conn,"
        SELECT log_id FROM resident_parking_logs 
        WHERE vehicle_id='{$row['vehicle_id']}' AND exit_time IS NULL
    ");

    $isInside = mysqli_num_rows($inside) > 0;
?>

<tr>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['vehicle_type']; ?></td>
<td><?php echo $row['wing_name']; ?></td>
<td><?php echo $row['unit_number']; ?></td>

<td class="<?php echo $isInside ? 'inside' : 'outside'; ?>">
    <?php echo $isInside ? "🟢 Inside" : "🔴 Outside"; ?>
</td>

<td>
<?php if($isInside){ ?>
    <a href="?exit=<?php echo $row['vehicle_id']; ?>" 
       class="btn-exit"
       onclick="return confirm('Allow Exit?')">Exit</a>
<?php } else { ?>
    <a href="?entry=<?php echo $row['vehicle_id']; ?>" 
       class="btn-entry"
       onclick="return confirm('Allow Entry?')">Entry</a>
<?php } ?>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>