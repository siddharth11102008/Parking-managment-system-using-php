<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$resultData = null;
$error = "";

// SEARCH LOGIC
if(isset($_POST['search'])){
    $vehicle = strtoupper(trim($_POST['vehicle']));

    if($vehicle == ""){
        $error = "Please enter vehicle number!";
    } else {

        $query = mysqli_query($conn,"
        SELECT g.*, s.slot_number, u.unit_number, w.wing_name
        FROM guest_parking_logs g
        JOIN parking_slots s ON g.slot_id = s.slot_id
        JOIN units u ON g.visiting_unit_id = u.unit_id
        JOIN wings w ON u.wing_id = w.wing_id
        WHERE g.vehicle_number='$vehicle'
        ORDER BY g.guest_id DESC
        LIMIT 1
        ");

        if(mysqli_num_rows($query) > 0){
            $resultData = mysqli_fetch_assoc($query);
        } else {
            $error = "No record found!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Search Guest</title>

<style>
body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:#f4f6f9;
}

/* Container */
.container{
    width:400px;
    margin:40px auto;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 20px rgba(0,0,0,0.1);
}

/* Heading */
h2{
    text-align:center;
    color:#2c3e50;
    margin-bottom:20px;
}

/* Input */
input{
    width:100%;
    padding:12px;
    border:1px solid #ccc;
    border-radius:6px;
    margin-bottom:15px;
    font-size:14px;
}

/* Button */
button{
    width:100%;
    padding:12px;
    background:#2c3e50;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-weight:bold;
}

button:hover{
    background:#1a252f;
}

/* Result Box */
.result{
    margin-top:20px;
    padding:15px;
    background:#ecf9ff;
    border-left:5px solid #3498db;
    border-radius:6px;
}

/* Error */
.error{
    margin-top:15px;
    padding:10px;
    background:#f8d7da;
    color:#721c24;
    border-left:5px solid #dc3545;
    border-radius:6px;
}

/* Status */
.status{
    font-weight:bold;
}

.inside{color:green;}
.exited{color:red;}

/* Back */
.back{
    display:block;
    margin-top:15px;
    text-align:center;
    text-decoration:none;
    color:#2c3e50;
    font-weight:bold;
}
</style>
</head>

<body>

<div class="container">

<h2>🔍 Search Guest</h2>

<form method="POST">
<input name="vehicle" placeholder="Enter Vehicle Number" required>
<button name="search">Search</button>
</form>

<?php if($error){ ?>
<div class="error"><?php echo $error; ?></div>
<?php } ?>

<?php if($resultData){ ?>
<div class="result">

<p><strong>Name:</strong> <?php echo $resultData['visitor_name']; ?></p>
<p><strong>Mobile:</strong> <?php echo $resultData['mobile']; ?></p>
<p><strong>Vehicle:</strong> <?php echo $resultData['vehicle_number']; ?></p>
<p><strong>Wing/Unit:</strong> <?php echo $resultData['wing_name']." - ".$resultData['unit_number']; ?></p>
<p><strong>Slot:</strong> <?php echo $resultData['slot_number']; ?></p>
<p><strong>Entry:</strong> <?php echo $resultData['entry_time']; ?></p>

<p class="status <?php echo $resultData['exit_time'] ? 'exited':'inside'; ?>">
Status: <?php echo $resultData['exit_time'] ? 'Exited' : 'Inside'; ?>
</p>

</div>
<?php } ?>

<a href="security-dashboard.php" class="back">← Back</a>

</div>

</body>
</html>