<?php
$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$q = mysqli_query($conn,"
SELECT r.*, v.vehicle_number, p.slot_number 
FROM resident_parking_logs r
JOIN vehicles v ON r.vehicle_id=v.vehicle_id
JOIN parking_slots p ON r.slot_id=p.slot_id
ORDER BY r.log_id DESC
");
?>

<h2>Resident Logs</h2>

<table border="1" cellpadding="10">
<tr>
<th>Vehicle</th>
<th>Slot</th>
<th>Entry</th>
<th>Exit</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($q)){ ?>
<tr>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['slot_number']; ?></td>
<td><?php echo $row['entry_time']; ?></td>
<td><?php echo $row['exit_time'] ? $row['exit_time'] : "Inside"; ?></td>
<td>
<a href="resident-log-view.php?id=<?php echo $row['log_id']; ?>">View</a>
</td>
</tr>
<?php } ?>
</table>