<?php

session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$resident = mysqli_num_rows(mysqli_query($conn,"
    SELECT * FROM resident_parking_logs WHERE exit_time IS NULL
"));

$guest = mysqli_num_rows(mysqli_query($conn,"
    SELECT * FROM guest_parking_logs WHERE exit_time IS NULL
"));
?>

<!DOCTYPE html>
<html>
<head>
<title>Security Dashboard</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:#f4f6f9;
}

/* Container */
.container{
    width:90%;
    margin:30px auto;
}

/* Welcome */
.welcome{
    text-align:center;
    font-size:18px;
    color:#2c3e50;
    margin-bottom:10px;
    font-weight:500;
}

/* Heading */
h2{
    text-align:center;
    color:#2c3e50;
    margin-bottom:25px;
    border-left:5px solid #3498db;
    padding-left:10px;
    display:inline-block;
}

/* Center heading */
.container h2{
    display:block;
    width:fit-content;
    margin:0 auto 30px auto;
}

/* Cards Layout */
.cards{
    display:flex;
    justify-content:center;
    gap:25px;
    flex-wrap:wrap;
}

/* Card */
.card{
    width:260px;
    background:white;
    padding:25px;
    border-radius:12px;
    text-align:center;
    box-shadow:0 8px 20px rgba(0,0,0,0.08);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-6px);
}

/* Top Border Colors */
.resident{
    border-top:5px solid #27ae60;
}

.guest{
    border-top:5px solid #e67e22;
}

/* Numbers */
.number{
    font-size:38px;
    font-weight:bold;
    margin:10px 0;
    color:#2c3e50;
}

/* Label */
.label{
    font-size:16px;
    color:#555;
}

/* Icons */
.icon{
    font-size:30px;
    margin-bottom:10px;
}

/* Mobile */
@media(max-width:500px){
    .card{
        width:90%;
    }
}
</style>
</head>

<body>

<div class="container">

<div class="welcome">
    Welcome, <?php echo $_SESSION['security_name']; ?> 👋
</div>

<h2>🚗 Security Dashboard</h2>

<div class="cards">

    <div class="card resident">
        <div class="label">Residents Inside</div>
        <div class="number"><?php echo $resident; ?></div>
    </div>

    <div class="card guest">
        <div class="label">Guests Inside</div>
        <div class="number"><?php echo $guest; ?></div>
    </div>

</div>

</div>

</body>
</html>