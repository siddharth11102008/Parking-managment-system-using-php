<?php
$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$id = $_SESSION['security_id'];
$row = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE user_id=$id"));
?>

<h2>Profile</h2>

<p>Name: <?php echo $row['name']; ?></p>
<p>Email: <?php echo $row['email']; ?></p>
<p>Mobile: <?php echo $row['mobile']; ?></p>