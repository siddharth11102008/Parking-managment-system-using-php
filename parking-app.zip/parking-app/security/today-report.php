<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

/* TODAY DATE */
$today = date('Y-m-d');

/* RESIDENT TODAY */
$resident = mysqli_query($conn,"
    SELECT v.vehicle_number, r.entry_time, r.exit_time, s.slot_number, 'Resident' AS type
    FROM resident_parking_logs r
    JOIN vehicles v ON r.vehicle_id = v.vehicle_id
    JOIN parking_slots s ON r.slot_id = s.slot_id
    WHERE DATE(r.entry_time) = '$today'
");

/* GUEST TODAY */
$guest = mysqli_query($conn,"
    SELECT g.vehicle_number, g.entry_time, g.exit_time, s.slot_number, 'Guest' AS type
    FROM guest_parking_logs g
    JOIN parking_slots s ON g.slot_id = s.slot_id
    WHERE DATE(g.entry_time) = '$today'
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Today Report</title>

<style>
body{
    font-family:Arial;
    background:#f4f6f9;
}

/* Container */
.container{
    width:90%;
    margin:30px auto;
    background:white;
    padding:20px;
    border-radius:8px;
    box-shadow:0 0 10px #ccc;
}

/* Heading */
h2{
    margin-bottom:15px;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

/* Badge */
.badge{
    padding:4px 8px;
    border-radius:5px;
    color:white;
}

.resident{ background:#27ae60; }
.guest{ background:#e67e22; }

.inside{ color:green; font-weight:bold; }
.exited{ color:red; font-weight:bold; }

/* Empty */
.empty{
    text-align:center;
    padding:15px;
    color:#777;
}
</style>
</head>

<body>

<div class="container">

<h2>📅 Today Report (<?php echo $today; ?>)</h2>

<table>
<tr>
<th>Type</th>
<th>Vehicle</th>
<th>Slot</th>
<th>Entry</th>
<th>Exit</th>
<th>Status</th>
</tr>

<?php
$count = 0;

/* RESIDENT LOOP */
while($r = mysqli_fetch_assoc($resident)){
    $count++;
?>
<tr>
<td><span class="badge resident">Resident</span></td>
<td><?php echo $r['vehicle_number']; ?></td>
<td><?php echo $r['slot_number']; ?></td>
<td><?php echo $r['entry_time']; ?></td>
<td><?php echo $r['exit_time'] ? $r['exit_time'] : "—"; ?></td>
<td class="<?php echo $r['exit_time'] ? 'exited' : 'inside'; ?>">
<?php echo $r['exit_time'] ? 'Exited' : 'Inside'; ?>
</td>
</tr>
<?php } ?>

<?php
/* GUEST LOOP */
while($g = mysqli_fetch_assoc($guest)){
    $count++;
?>
<tr>
<td><span class="badge guest">Guest</span></td>
<td><?php echo $g['vehicle_number']; ?></td>
<td><?php echo $g['slot_number']; ?></td>
<td><?php echo $g['entry_time']; ?></td>
<td><?php echo $g['exit_time'] ? $g['exit_time'] : "—"; ?></td>
<td class="<?php echo $g['exit_time'] ? 'exited' : 'inside'; ?>">
<?php echo $g['exit_time'] ? 'Exited' : 'Inside'; ?>
</td>
</tr>
<?php } ?>

<?php if($count == 0){ ?>
<tr>
<td colspan="6" class="empty">No Records Found Today</td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>