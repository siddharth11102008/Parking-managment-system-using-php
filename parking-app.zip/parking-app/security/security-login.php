<?php
session_start();
$conn = mysqli_connect("localhost","root","","parking_db");

$error = ""; // ✅ always define

if(isset($_POST['login'])){

    // ✅ safe input handling
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if($username=="" || $password==""){
        $error = "All fields are required!";
    } else {

        $sql= "SELECT * FROM users 
            WHERE email='$username' 
            AND role='security' 
            AND status='active'";

        $q = mysqli_query($conn,$sql);

        if($q && mysqli_num_rows($q)==1){

            $row = mysqli_fetch_assoc($q);

            // ✅ password check
            if($password == $row['password']){
                $_SESSION['security_id'] = $row['user_id'];
                $_SESSION['security_name'] = $row['name'];

                header("Location: security-dashboard.php");
                exit();
            } else {
                $error="Wrong Password";
            }

        } else {
            $error="Invalid User or Inactive Account";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Security Login</title>

<style>

/* Reset */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Segoe UI', sans-serif;
}

/* Background */
body{
    height:100vh;
    background: linear-gradient(135deg, #1f2c3a, #2c3e50);
    display:flex;
    justify-content:center;
    align-items:center;
}

/* Card */
.box{
    width:350px;
    background:white;
    padding:30px;
    border-radius:10px;
    box-shadow:0 10px 25px rgba(0,0,0,0.3);
    text-align:center;
}

/* Title */
.box h2{
    margin-bottom:20px;
    color:#2c3e50;
}

/* Inputs */
input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:1px solid #ccc;
    border-radius:5px;
    transition:0.3s;
}

/* Focus effect */
input:focus{
    border-color:#2c3e50;
    outline:none;
    box-shadow:0 0 5px rgba(44,62,80,0.5);
}

/* Button */
button{
    width:100%;
    padding:12px;
    background:#2c3e50;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
    transition:0.3s;
    font-size:16px;
}

/* Hover */
button:hover{
    background:#34495e;
}

/* Error */
.error{
    color:red;
    margin-bottom:10px;
}

/* Footer text */
.footer{
    margin-top:15px;
    font-size:13px;
    color:#777;
}

</style>

</head>
<body>

<div class="box">

<h2>🔐 Security Login</h2>

<?php if($error!="") echo "<div class='error'>$error</div>"; ?>

<form method="POST">
<input type="text" name="username" placeholder="Email Address" required>
<input type="password" name="password" placeholder="Password" required>
<button name="login">Login</button>
</form>

<div class="footer">
Smart Parking System 🚗
</div>

</div>

</body>
</html>