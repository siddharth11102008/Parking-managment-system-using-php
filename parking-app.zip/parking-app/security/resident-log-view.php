<?php
$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$id = $_GET['id'];

$row = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT r.*, v.vehicle_number, p.slot_number 
FROM resident_parking_logs r
JOIN vehicles v ON r.vehicle_id=v.vehicle_id
JOIN parking_slots p ON r.slot_id=p.slot_id
WHERE r.log_id=$id
"));
?>

<h2>Resident Log Detail</h2>

<p>Vehicle: <?php echo $row['vehicle_number']; ?></p>
<p>Slot: <?php echo $row['slot_number']; ?></p>
<p>Entry: <?php echo $row['entry_time']; ?></p>
<p>Exit: <?php echo $row['exit_time']; ?></p>