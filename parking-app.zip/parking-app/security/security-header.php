<?php
if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}
?>

<style>
.header{
    background:#2c3e50;
    padding:12px;
}

.header a{
    color:white;
    text-decoration:none;
    margin-right:15px;
    font-weight:bold;
}

.header a:hover{
    text-decoration:underline;
}
</style>

<div class="header">

<a href="security-dashboard.php">Dashboard</a>
<a href="resident-entry.php">Resident Entry</a>
<a href="guest-entry.php">Guest Entry</a>
<a href="guest-exit.php">Guest Exit</a>

<!-- ✅ NEW FEATURES -->
<a href="guest-log-list.php">Guest Logs</a>
<a href="search-guest.php">Search Guest</a>
<a href="overstay-report.php">Overstay</a>
<a href="security-logout.php">Logout</a>

</div>