<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");

$id = (int)$_GET['id'];

/* CHECK IF EXITED */
$check = mysqli_query($conn,"
    SELECT * FROM guest_parking_logs 
    WHERE guest_id=$id AND exit_time IS NOT NULL
");

if(mysqli_num_rows($check)>0){

    mysqli_query($conn,"
        DELETE FROM guest_parking_logs 
        WHERE guest_id=$id
    ");

    header("Location: guest-log-list.php?msg=1");

} else {

    header("Location: guest-log-list.php?error=1");

}
exit();
?>