<?php
$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$q = mysqli_query($conn,"
SELECT 
    s.slot_id,
    s.slot_number,
    s.slot_type,
    
    CASE 
        WHEN s.slot_type='guest' AND EXISTS (
            SELECT 1 FROM guest_parking_logs g 
            WHERE g.slot_id = s.slot_id AND g.exit_time IS NULL
        ) THEN 'occupied'

        WHEN s.slot_type='resident' AND EXISTS (
            SELECT 1 FROM resident_parking_logs r 
            WHERE r.slot_id = s.slot_id AND r.exit_time IS NULL
        ) THEN 'occupied'

        ELSE s.status
    END AS real_status

FROM parking_slots s

ORDER BY FIELD(s.slot_type,'resident','guest'), s.slot_number
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Slot Status</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

/* Container */
.container{
    width:90%;
    margin:30px auto;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 25px rgba(0,0,0,0.1);
    animation:fadeIn 0.4s ease;
}

/* Heading */
h2{
    margin-bottom:20px;
    color:#2c3e50;
    border-left:5px solid #3498db;
    padding-left:10px;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    border-radius:10px;
    overflow:hidden;
}

/* Header */
th{
    background:linear-gradient(45deg,#2c3e50,#34495e);
    color:white;
    padding:12px;
}

/* Cells */
td{
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:center;
}

/* Zebra */
tr:nth-child(even){
    background:#f9fbfc;
}

/* Hover */
tr:hover{
    background:#eef5ff;
}

/* Status Badges */
.status{
    padding:5px 12px;
    border-radius:20px;
    color:white;
    font-size:12px;
    font-weight:bold;
}

.available{ background:#27ae60; }
.occupied{ background:#e74c3c; }
.reserved{ background:#f39c12; }
.blocked{ background:#7f8c8d; }

/* Animation */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(10px);}
    to{opacity:1; transform:translateY(0);}
}

/* Responsive */
@media(max-width:768px){
    table,thead,tbody,th,td,tr{
        display:block;
    }

    th{display:none;}

    tr{
        margin-bottom:12px;
        background:white;
        border-radius:10px;
        padding:10px;
        box-shadow:0 5px 10px rgba(0,0,0,0.05);
    }

    td{
        text-align:left;
        padding:8px;
        border:none;
    }

    td:before{
        content:attr(data-label);
        font-weight:bold;
        display:block;
        color:#555;
    }
}
</style>

</head>

<body>

<div class="container">

<h2>🚗 Parking Slot Status</h2>

<table>
<tr>
<th>Slot</th>
<th>Type</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($q)){ ?>
<tr>
<td data-label="Slot"><?php echo $row['slot_number']; ?></td>
<td data-label="Type"><?php echo ucfirst($row['slot_type']); ?></td>

<td data-label="Status">
<span class="status <?php echo $row['real_status']; ?>">
<?php echo ucfirst($row['real_status']); ?>
</span>
</td>

</tr>
<?php } ?>

</table>

</div>

</body>
</html>