<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

if(!isset($_GET['id'])){
    die("Invalid Request");
}

$id = intval($_GET['id']);

$result = mysqli_query($conn, "
    SELECT g.*, s.slot_number
    FROM guest_parking_logs g
    JOIN parking_slots s ON g.slot_id = s.slot_id
    WHERE g.guest_id = $id
");

$data = mysqli_fetch_assoc($result);

if(!$data){
    die("Record not found");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Guest Log View</title>

<style>
body{
    font-family:Arial;
    background:#f4f6f9;
}

.container{
    width:50%;
    margin:40px auto;
    background:white;
    padding:25px;
    box-shadow:0 0 10px #ccc;
    border-radius:8px;
}

h2{
    text-align:center;
    margin-bottom:20px;
    color:#2c3e50;
}

p{
    font-size:16px;
    margin:10px 0;
}

.label{
    font-weight:bold;
    color:#34495e;
}

.back{
    display:inline-block;
    margin-top:15px;
    padding:8px 12px;
    background:#3498db;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

.back:hover{
    background:#2980b9;
}
</style>

</head>

<body>

<div class="container">

<h2>Guest Parking Details</h2>

<p><span class="label">Visitor:</span> <?php echo $data['visitor_name']; ?></p>

<p><span class="label">Vehicle Number:</span> <?php echo $data['vehicle_number']; ?></p>

<p><span class="label">Slot Number:</span> <?php echo $data['slot_number']; ?></p>

<p><span class="label">Entry Time:</span> <?php echo $data['entry_time']; ?></p>

<p><span class="label">Exit Time:</span> 
<?php echo $data['exit_time'] ? $data['exit_time'] : "Not Exited"; ?>
</p>

<p><span class="label">Status:</span> 
<?php echo $data['exit_time'] ? "Exited" : "Inside"; ?>
</p>

<a class="back" href="guest-log-list.php">⬅ Back</a>

</div>

</body>
</html>