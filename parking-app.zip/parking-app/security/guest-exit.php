<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}

include("security-header.php");

/* ================= EXIT ACTION ================= */
if(isset($_GET['exit'])){
    $id = (int)$_GET['exit'];

    // GET ACTIVE LOG ONLY
    $row = mysqli_fetch_assoc(mysqli_query($conn,"
        SELECT * FROM guest_parking_logs 
        WHERE guest_id='$id' AND exit_time IS NULL
    "));

    if($row){

        $slot_id = $row['slot_id'];

        // UPDATE EXIT TIME
        $update = mysqli_query($conn,"
            UPDATE guest_parking_logs 
            SET exit_time = NOW() 
            WHERE guest_id = '$id'
        ");

        if($update){

            // ✅ FREE SLOT ONLY IF NO OTHER ACTIVE ENTRY USING IT
            $checkSlot = mysqli_query($conn,"
                SELECT * FROM guest_parking_logs 
                WHERE slot_id='$slot_id' AND exit_time IS NULL
            ");

            if(mysqli_num_rows($checkSlot) == 0){
                mysqli_query($conn,"
                    UPDATE parking_slots 
                    SET status='available' 
                    WHERE slot_id='$slot_id'
                ");
            }

            $msg = "✅ Guest Exit Successful!";
        } else {
            $msg = "❌ Error while exiting!";
        }

    } else {
        $msg = "⚠️ Guest already exited!";
    }
}

/* ================= FETCH ACTIVE GUESTS ================= */
$result = mysqli_query($conn,"
    SELECT g.*, s.slot_number 
    FROM guest_parking_logs g
    JOIN parking_slots s ON g.slot_id = s.slot_id
    WHERE g.exit_time IS NULL
    ORDER BY g.entry_time DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Guest Exit</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;}

body{
    font-family:'Segoe UI';
    background:linear-gradient(135deg,#eef2f3,#dfe9f3);
}

.container{
    width:90%;
    margin:30px auto;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 25px rgba(0,0,0,0.1);
}

h2{
    margin-bottom:20px;
    color:#2c3e50;
    border-left:5px solid #e74c3c;
    padding-left:10px;
}

table{
    width:100%;
    border-collapse:collapse;
    border-radius:10px;
    overflow:hidden;
}

th{
    background:#2c3e50;
    color:white;
    padding:12px;
}

td{
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:center;
}

tr:nth-child(even){background:#f9fbfc;}
tr:hover{background:#eef5ff;}

.btn{
    padding:6px 14px;
    background:#e74c3c;
    color:white;
    text-decoration:none;
    border-radius:20px;
}

.btn:hover{background:#c0392b;}

.msg{
    padding:10px;
    margin-bottom:10px;
    border-radius:5px;
    background:#d4edda;
    color:#155724;
}

.empty{
    text-align:center;
    padding:20px;
    color:#888;
}
</style>
</head>

<body>

<div class="container">

<h2>🚗 Guest Exit Panel</h2>

<?php if(isset($msg)) echo "<div class='msg'>$msg</div>"; ?>

<table>
<tr>
<th>Visitor</th>
<th>Mobile</th>
<th>Vehicle</th>
<th>Slot</th>
<th>Entry Time</th>
<th>Action</th>
</tr>

<?php if(mysqli_num_rows($result) > 0){ ?>
    <?php while($row=mysqli_fetch_assoc($result)){ ?>
    <tr>
        <td><?php echo $row['visitor_name']; ?></td>
        <td><?php echo $row['mobile']; ?></td>
        <td><?php echo $row['vehicle_number']; ?></td>
        <td><?php echo $row['slot_number']; ?></td>
        <td><?php echo $row['entry_time']; ?></td>
        <td>
            <a class="btn" 
               href="?exit=<?php echo $row['guest_id']; ?>" 
               onclick="return confirm('Confirm Exit?')">
               Exit
            </a>
        </td>
    </tr>
    <?php } ?>
<?php } else { ?>
<tr>
<td colspan="6" class="empty">No Guests Inside 🚫</td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>