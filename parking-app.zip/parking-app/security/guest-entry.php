<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}

include("security-header.php");

// FETCH UNITS WITH WING
$units = mysqli_query($conn,"
    SELECT u.*, w.wing_name 
    FROM units u 
    JOIN wings w ON u.wing_id = w.wing_id
");

// ================= ENTRY LOGIC =================
if(isset($_POST['submit'])){

    $name    = trim($_POST['name']);
    $mobile  = trim($_POST['mobile']);
    $unit    = (int)$_POST['unit'];
    $vehicle = strtoupper(trim($_POST['vehicle']));
    $security_id = $_SESSION['security_id'];

    if($name=="" || $mobile=="" || $vehicle==""){
        $msg = "<div class='error'>All fields are required!</div>";
    } else {

        // CHECK VEHICLE ALREADY INSIDE
        $check = mysqli_query($conn,"
            SELECT * FROM guest_parking_logs 
            WHERE vehicle_number='$vehicle' AND exit_time IS NULL
        ");

        if(mysqli_num_rows($check) > 0){
            $msg = "<div class='error'>Vehicle already inside!</div>";
        } else {

            // ✅ FIXED SLOT QUERY (NO DUPLICATE SLOT)
            $slotQuery = mysqli_query($conn,"
                SELECT * FROM parking_slots ps
                WHERE ps.slot_type='guest'
                AND ps.slot_id NOT IN (
                    SELECT slot_id FROM guest_parking_logs 
                    WHERE exit_time IS NULL
                )
                LIMIT 1
            ");

            if(mysqli_num_rows($slotQuery) == 0){
                $msg = "<div class='error'>No Guest Slot Available!</div>";
            } else {

                $slot = mysqli_fetch_assoc($slotQuery);
                $slot_id = $slot['slot_id'];

                // INSERT LOG
                $insert = mysqli_query($conn,"
                    INSERT INTO guest_parking_logs
                    (visitor_name,mobile,visiting_unit_id,vehicle_number,slot_id,entry_time,created_by)
                    VALUES ('$name','$mobile',$unit,'$vehicle',$slot_id,NOW(),$security_id)
                ");

                if(!$insert){
                    die("Insert Error: " . mysqli_error($conn));
                }

                // UPDATE SLOT STATUS (optional but good)
                mysqli_query($conn,"
                    UPDATE parking_slots 
                    SET status='occupied' 
                    WHERE slot_id=$slot_id
                ");

                $msg = "<div class='success'>✅ Guest Entry Successful! Slot: ".$slot['slot_number']."</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Guest Entry</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background:#f4f6f9;
}

/* Container */
.box{
    width:420px;
    margin:50px auto;
    background:#ffffff;
    padding:25px;
    border-radius:12px;
    box-shadow:0 8px 25px rgba(0,0,0,0.08);
    animation:fadeIn 0.3s ease;
}

/* Heading */
h2{
    text-align:center;
    margin-bottom:20px;
    color:#2c3e50;
    border-left:5px solid #3498db;
    padding-left:10px;
}

/* Inputs */
input, select{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:1px solid #ddd;
    border-radius:8px;
    font-size:14px;
    transition:0.2s;
}

input:focus, select:focus{
    border-color:#3498db;
    box-shadow:0 0 5px rgba(52,152,219,0.2);
    outline:none;
}

/* Button */
button{
    width:100%;
    padding:12px;
    background:linear-gradient(45deg,#2c3e50,#34495e);
    color:white;
    border:none;
    border-radius:25px;
    cursor:pointer;
    font-size:15px;
    font-weight:bold;
    transition:0.3s;
}

button:hover{
    background:linear-gradient(45deg,#1a252f,#2c3e50);
}

/* Success Message */
.success{
    background:#d4edda;
    color:#155724;
    padding:10px;
    border-radius:6px;
    margin-bottom:10px;
    border-left:5px solid #28a745;
}

/* Error Message */
.error{
    background:#f8d7da;
    color:#721c24;
    padding:10px;
    border-radius:6px;
    margin-bottom:10px;
    border-left:5px solid #dc3545;
}

/* Back Button */
.back{
    display:block;
    text-align:center;
    margin-top:15px;
    text-decoration:none;
    color:#2c3e50;
    font-weight:bold;
    transition:0.3s;
}

.back:hover{
    color:#3498db;
}

/* Animation */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(10px);}
    to{opacity:1; transform:translateY(0);}
}

/* Mobile */
@media(max-width:480px){
    .box{
        width:90%;
    }
}
</style>
</head>

<body>

<div class="box">

<h2>🚗 Guest Entry</h2>

<?php if(isset($msg)) echo $msg; ?>

<form method="POST">

<input name="name" placeholder="Visitor Name" required>

<input name="mobile" placeholder="Mobile Number" required>

<input name="vehicle" placeholder="Vehicle Number" required>

<select name="unit" required>
<option value="">Select Unit</option>
<?php while($u=mysqli_fetch_assoc($units)){ ?>
<option value="<?php echo $u['unit_id']; ?>">
<?php echo $u['wing_name']." - ".$u['unit_number']; ?>
</option>
<?php } ?>
</select>

<button name="submit">Entry</button>

</form>

<a href="security-dashboard.php" class="back">← Back</a>

</div>

</body>
</html>