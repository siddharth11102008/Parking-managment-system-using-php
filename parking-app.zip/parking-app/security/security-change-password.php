<?php
$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

$id = $_SESSION['security_id'];

if(isset($_POST['update'])){
    $old=$_POST['old'];
    $new=$_POST['new'];

    $row=mysqli_fetch_assoc(mysqli_query($conn,"SELECT password FROM users WHERE user_id=$id"));

    if($old==$row['password']){
        mysqli_query($conn,"UPDATE users SET password='$new' WHERE user_id=$id");
        echo "Updated";
    } else {
        echo "Wrong Password";
    }
}
?>

<form method="POST">
<input type="password" name="old" placeholder="Old">
<input type="password" name="new" placeholder="New">
<button name="update">Change</button>
</form>