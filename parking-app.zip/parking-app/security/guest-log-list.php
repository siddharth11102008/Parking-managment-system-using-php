<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

/* FETCH ALL LOGS */
$result = mysqli_query($conn,"
    SELECT g.*, s.slot_number
    FROM guest_parking_logs g
    JOIN parking_slots s ON g.slot_id = s.slot_id
    ORDER BY g.guest_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Guest Log List</title>

<style>
body{font-family:Arial;background:#f4f6f9;}

.container{
    width:95%;
    margin:30px auto;
    background:white;
    padding:20px;
    box-shadow:0 0 10px #ccc;
    border-radius:8px;
}

h2{margin-bottom:15px;}

table{width:100%;border-collapse:collapse;}

th,td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

tr:nth-child(even){background:#f9f9f9;}

.btn{
    padding:5px 10px;
    text-decoration:none;
    color:white;
    border-radius:4px;
    font-size:13px;
}

.view{background:#3498db;}
.delete{background:#e74c3c;}

.view:hover{background:#2980b9;}
.delete:hover{background:#c0392b;}

.msg{color:green;}
.error{color:red;}
</style>
</head>

<body>

<div class="container">

<h2>📄 Guest Parking Logs</h2>

<?php
if(isset($_GET['msg'])) echo "<p class='msg'>Record Deleted</p>";
if(isset($_GET['error'])) echo "<p class='error'>Cannot delete active guest!</p>";
?>

<table>
<tr>
<th>Visitor</th>
<th>Vehicle</th>
<th>Slot</th>
<th>Entry</th>
<th>Exit</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>
<tr>
<td><?php echo $row['visitor_name']; ?></td>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['slot_number']; ?></td>
<td><?php echo $row['entry_time']; ?></td>
<td><?php echo $row['exit_time'] ? $row['exit_time'] : "—"; ?></td>

<td>
<?php echo $row['exit_time'] ? "Exited" : "Inside"; ?>
</td>

<td>
<a class="btn view" href="guest-log-view.php?id=<?php echo $row['guest_id']; ?>">View</a>

<a class="btn delete" 
   href="guest-log-delete.php?id=<?php echo $row['guest_id']; ?>"
   onclick="return confirm('Delete this log?')">
Delete
</a>
</td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>