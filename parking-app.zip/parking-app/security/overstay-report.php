<?php
session_start();

if(!isset($_SESSION['security_id'])){
    header("Location: security-login.php");
    exit();
}

$conn = mysqli_connect("localhost","root","","parking_db");
include("security-header.php");

/* LIMIT IN HOURS */
$limit = 2;

/* FETCH ONLY ACTIVE OVERSTAY (INSIDE) */
$q = mysqli_query($conn,"
    SELECT g.*, s.slot_number,
    TIMESTAMPDIFF(MINUTE, g.entry_time, NOW()) AS minutes_stayed
    FROM guest_parking_logs g
    JOIN parking_slots s ON g.slot_id = s.slot_id
    WHERE g.exit_time IS NULL
    AND TIMESTAMPDIFF(HOUR, g.entry_time, NOW()) > $limit
    ORDER BY minutes_stayed DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Overstay Report</title>

<style>
body{
    font-family:Arial;
    background:#f4f6f9;
}

/* Container */
.container{
    width:90%;
    margin:30px auto;
    background:white;
    padding:20px;
    border-radius:8px;
    box-shadow:0 0 10px #ccc;
}

/* Heading */
h2{
    margin-bottom:15px;
    color:#e74c3c;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
}

th,td{
    padding:10px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

/* Highlight */
.over{
    color:red;
    font-weight:bold;
}

/* Button */
.btn{
    padding:5px 10px;
    background:#e74c3c;
    color:white;
    text-decoration:none;
    border-radius:4px;
}

.btn:hover{
    background:#c0392b;
}

/* Empty */
.empty{
    text-align:center;
    padding:15px;
    color:#777;
}
</style>
</head>

<body>

<div class="container">

<h2>⏱ Overstay Vehicles (><?php echo $limit; ?> hrs)</h2>

<table>
<tr>
<th>Visitor</th>
<th>Vehicle</th>
<th>Slot</th>
<th>Entry Time</th>
<th>Stayed</th>
<th>Action</th>
</tr>

<?php
if(mysqli_num_rows($q) > 0){
    while($row=mysqli_fetch_assoc($q)){

        $hours = floor($row['minutes_stayed']/60);
        $minutes = $row['minutes_stayed'] % 60;
?>
<tr>
<td><?php echo $row['visitor_name']; ?></td>
<td><?php echo $row['vehicle_number']; ?></td>
<td><?php echo $row['slot_number']; ?></td>
<td><?php echo $row['entry_time']; ?></td>

<td class="over">
<?php echo $hours."h ".$minutes."m"; ?>
</td>

<td>
<a class="btn" href="guest-exit.php?exit=<?php echo $row['guest_id']; ?>">
Force Exit
</a>
</td>

</tr>
<?php 
    }
} else {
    echo "<tr><td colspan='6' class='empty'>No Overstay Vehicles ✅</td></tr>";
}
?>

</table>

</div>

</body>
</html>